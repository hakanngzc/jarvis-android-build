# JARVIS 1.6.4.14 CONFIRM-FIRST LOCK

Bu sürümde çalışan action pipeline yeniden yazılmadı. Kaynak kodda zaten bulunan ses-tamamlanınca-eylem sözleşmesi zorunlu QA kuralı haline getirildi.

Kilitlenen yollar:
- Uygulama açma: `app_open` sesi tamamlanmadan `startActivity` çalışmaz.
- Alarm kurma: `alarm_schedule` sesi tamamlanmadan `AlarmStore.schedule` çalışmaz.
- Fener: `torch_on` / `torch_off` sesi tamamlanmadan `setTorchMode` çalışmaz.
- Fener kamera izni: `torch_permission` sesi tamamlanmadan izin diyaloğu istenmez.
- Legacy telefon eylemleri: `capturingAction` ile yakalanır ve `deferredAction` olarak ses callback'ine verilir.
- Ses oynatma başarısız olursa `after` eylemi çalıştırılmaz.

Bu nedenle APK runtime DEX kodu 1.6.4.13 ile aynıdır. DEX içinde yalnız görünür sürüm bannerı ile checksum/signature header değişir; manifest sürümü 79 / `1.6.4.14-confirm-safe1` olarak güncellenir.
