# JARVIS 1.6.4.15 SMART FALLBACK SAFE

Bu sürüm, 1.6.4.14'te zaten mevcut olan güvenli komut netleştirme davranışını yeniden yazmadan QA sözleşmesine kilitler.

Kilitlemeler:
- Birden fazla / çelişkili konuşma sonucu doğrudan işlem çalıştırmaz; seçim ister.
- Düşük güvenli sonuç "Doğru mu duydum?" onayı ister.
- Kullanıcı "Tekrar dinle" / "Yeniden dinle" ile yeni dinleme başlatabilir.
- `unknown` ve `clarify` sonuçlarında after-action null kalır; yakalanmış telefon eylemi çalışmaz.
- Ses tanıma no-match durumunda açıklayıcı yeniden deneme mesajı vardır.
- `unknown`, `clarify`, `speech_choose` için çevrimdışı doğal ses bankası mevcuttur.

Runtime komut/action kodu değiştirilmedi. APK, 1.6.4.14 ile aynı DEX davranışını taşır; yalnız sürüm bannerı/manifest güncellendi. Bu, önceki DEX verifier çökme sınıfına yeni risk eklememek için bilinçli tasarımdır.
