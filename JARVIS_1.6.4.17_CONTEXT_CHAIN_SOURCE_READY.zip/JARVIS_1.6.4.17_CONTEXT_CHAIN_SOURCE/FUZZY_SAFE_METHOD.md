# JARVIS 1.6.4.13 FUZZY COMMAND SAFE

Base: 1.6.4.12 APP COMMAND SAFE.

Bu sürüm genel ve agresif fuzzy matching yapmaz. Yanlış sistem eylemi riskini azaltmak için yalnızca açıkça uygulama açma niyeti olarak çözümlenmiş komutlarda dört bilinen uygulamanın ASR varyasyonları genişletildi.

- YouTube: `youtube`, `youtub`, `yutub`, `yutube` benzeri varyasyonlar
- Spotify: `spotify`, `spotif`, `spotifi`, `spotifa` benzeri varyasyonlar
- WhatsApp: `whatsapp`, `whatsap`, `vatsap`
- Instagram: `instagram`, `instagra`, `instagrami`

APK içindeki dört regex kaydı mevcut kayıtlarla aynı byte uzunluğundadır. Yeni string_data eklenmez, DEX boyutu/offset/padding yapısı değişmez. Alarm, fener, notlar, saat/tarih, mikrofon, wake-word ve ses kodu değiştirilmez.
