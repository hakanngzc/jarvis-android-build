import com.hakan.jarvis.*;
public class WakeWordTest {
  static int n=0;
  static void ok(boolean b,String m){if(!b)throw new AssertionError(m);n++;}
  public static void main(String[] args){
    String[] yes={"jarvis","carvis","cervis","jervis","jarviz","carviz","hey jarvis","hey carvis","Jarvis,","hey Jervis:"};
    for(String s:yes)ok(CommandLanguage.isWake(s),"wake "+s);
    String[] commands={"jarvis saat kaç","carvis alarm kur","cervis feneri aç","jervis notlarımı oku","jarviz tarih","carviz spotify aç"};
    for(String s:commands)ok(!CommandLanguage.clean(s).equals(PhoneCommand.norm(s)),"strip "+s);
    String[] no={"carlos","jarmis","fenerbahce","jarvisli","carvizyon"};
    for(String s:no)ok(!CommandLanguage.isWake(s),"false-positive "+s);
    System.out.println("TOTAL "+n+" PASS");
  }
}
