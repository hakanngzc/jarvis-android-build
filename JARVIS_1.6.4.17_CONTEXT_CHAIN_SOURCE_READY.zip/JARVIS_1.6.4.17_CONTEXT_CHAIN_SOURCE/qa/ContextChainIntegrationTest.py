from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
a=(ROOT/'app/src/main/java/com/hakan/jarvis/HybridActivity.java').read_text(encoding='utf8')
c=(ROOT/'app/src/main/java/com/hakan/jarvis/CommandChain.java').read_text(encoding='utf8')
checks={
'parser_present':'public final class CommandChain' in c,
'temporal_alarm_guard':'DURATION.matcher(left).matches() && ALARM_AFTER.matcher(right).matches()' in c,
'max_two_guard':'en fazla iki işlem' in c,
'new_input_clears_chain':'if(!internalChainDispatch)' in a and 'chainedNext="";CommandChain.Result chain=CommandChain.parse(raw);' in a,
'first_step_safety':'private boolean chainFirstSafe' in a and 'pc.kind.equals("torch")' in a,
'terminal_whitelist':'chainTerminalKey' in a and 'torch_on|torch_off' in a,
'failure_clears':'chainFailureKey' in a and 'chainedNext="";' in a,
'voice_completion_drives_next':'voice.speak' in a and 'continueChain();' in a,
'no_fixed_delay':'postDelayed' not in a[a.find('private void continueChain'):a.find('private void say',a.find('private void continueChain'))],
'on_pause_clears':'onPause()' in a and 'deferredAction=null;chainedNext="";super.onPause();' in a,
'user_stop_clears':'deferredAction=null;chainedNext="";voiceStatus.setText("Ses: DURDU")' in a,
}
for k,v in checks.items(): print(k,'PASS' if v else 'FAIL')
assert all(checks.values()),[k for k,v in checks.items() if not v]
print('TOTAL',len(checks),'PASS')
