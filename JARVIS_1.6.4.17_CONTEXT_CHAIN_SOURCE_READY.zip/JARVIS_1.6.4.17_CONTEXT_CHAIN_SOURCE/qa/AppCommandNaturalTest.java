import java.util.regex.*;
public class AppCommandNaturalTest {
  static int n=0;
  static void ok(boolean b,String s){if(!b)throw new AssertionError(s);n++;}
  static String target(String s){
    Matcher m=Pattern.compile("^(?:uygulama )?(.+?) +(ac|baslat|gir(sene)?|calistir)()$").matcher(s);
    if(!m.matches())return null;
    return m.group(1).replaceFirst(" +uyg.*$| +bi\\Z","").replaceFirst("'(?:yi|yu|y[ui]|i|u)$","").trim();
  }
  public static void main(String[] args){
    String[][] yes={{"spotify ac","spotify"},{"spotify bi ac","spotify"},{"spotify uygulamasini ac","spotify"},{"uygulama spotify ac","spotify"},{"spotify baslat","spotify"},{"youtube gir","youtube"},{"youtube girsene","youtube"},{"whatsapp calistir","whatsapp"},{"instagram bi calistir","instagram"},{"spotify'i ac","spotify"},{"kamera ac","kamera"},{"ayarlar ac","ayarlar"}};
    for(String[] p:yes)ok(p[1].equals(target(p[0])),p[0]);
    for(String s:new String[]{"spotify kapat","spotify sil","gir spotify","uygulama","youtube cal"})ok(target(s)==null,"reject "+s);
    System.out.println("TOTAL "+n+" PASS");
  }
}
