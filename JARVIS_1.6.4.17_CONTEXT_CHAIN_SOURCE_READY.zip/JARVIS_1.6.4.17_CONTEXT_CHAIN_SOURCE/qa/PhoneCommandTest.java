import com.hakan.jarvis.PhoneCommand;
public class PhoneCommandTest {
 static int count=0;static void check(boolean v,String label){if(!v)throw new AssertionError(label);count++;System.out.println("PASS "+label);}
 static void time(String s,int h,int m){PhoneCommand c=PhoneCommand.parse(s);check(c!=null&&c.error==null&&c.hour==h&&c.minute==m,s+(c==null?"":": "+c.error));}
 static void bad(String s){PhoneCommand c=PhoneCommand.parse(s);check(c!=null&&c.error!=null,s);}
 public static void main(String[] args){
 time("Sabah yediye alarm kur",7,0);time("akşam yediye alarm kur",19,0);time("19:30'a alarm kur",19,30);time("07.05 alarm kur",7,5);time("sabah yedi buçuk alarm kur",7,30);time("sabah on bire alarm kur",11,0);time("gece on ikiye alarm kur",0,0);time("23:59 alarm ayarla",23,59);time("Jarvis sabah altıya alarm kur",6,0);time("saat yirmi üçe alarm kur",23,0);time("öğleden sonra üçe alarm kur",15,0);
 time("7ye alarm kur",7,0);bad("25:00 alarm kur");bad("07:99 alarm kur");time("yarın 07:00 alarm kur",7,0);check(PhoneCommand.parse("20 dakika sonra alarm kur").plan.when>System.currentTimeMillis(),"relative duration accepted");bad("her gün 07:00 alarm kur");bad("sabah akşam yediye alarm kur");bad("alarm kur");bad("7 ve 8 alarm kur");
 check(PhoneCommand.parse("feneri aç").enabled,"torch on");check(!PhoneCommand.parse("feneri kapat").enabled,"torch off");bad("feneri aç ve kapat");
 check(PhoneCommand.parse("YouTube’u aç").target.equals("youtube"),"apostrophe suffix");check(PhoneCommand.parse("Spotify uygulamasını aç").target.equals("spotify"),"app phrase");check(PhoneCommand.parse("Jarvis YouTube aç").kind.equals("app"),"wake prefix");check(PhoneCommand.matchesLabel("spotifyi","Spotify"),"Turkish suffix label");check(!PhoneCommand.matchesLabel("spot","Spotify"),"no dangerous fuzzy match");check(PhoneCommand.parse("hesapla 2+2")==null,"legacy calc preserved");check(PhoneCommand.parse("müzik aç")==null,"legacy music preserved");check(PhoneCommand.parse("not al feneri aç")==null,"note text cannot execute torch");check(PhoneCommand.parse("not al sabah yediye alarm kur")==null,"note text cannot set alarm");check(PhoneCommand.parse("bilgi alarm nedir")==null,"knowledge query preserved");System.out.println("TOTAL "+count+" PASS");
 }
}
