public class FuzzyAliasTest {
  static int n=0;
  static void ok(boolean b,String s){if(!b)throw new AssertionError(s);n++;}
  static String pkg(String a){
    a=a.replace(" ","").replaceFirst("'(yi|yu|i|u)$","");
    if(a.matches("youtube?|yutub.?"))return "youtube";
    if(a.matches("spotify?|spotif."))return "spotify";
    if(a.matches("whatsapp?|vatsap"))return "whatsapp";
    if(a.matches("instagram?(i)?$"))return "instagram";
    return null;
  }
  public static void main(String[] args){
    String[][] yes={{"youtube","youtube"},{"youtub","youtube"},{"yutub","youtube"},{"yutube","youtube"},{"spotify","spotify"},{"spotif","spotify"},{"spotifi","spotify"},{"spotifa","spotify"},{"whatsapp","whatsapp"},{"whatsap","whatsapp"},{"vatsap","whatsapp"},{"instagram","instagram"},{"instagra","instagram"},{"instagrami","instagram"},{"instagram'i","instagram"}};
    for(String[] p:yes)ok(p[1].equals(pkg(p[0])),p[0]);
    for(String s:new String[]{"youtubeabc","spotifxx","whats","vatsa","inst","camera","telegram"})ok(pkg(s)==null,"reject "+s);
    System.out.println("TOTAL "+n+" PASS");
  }
}
