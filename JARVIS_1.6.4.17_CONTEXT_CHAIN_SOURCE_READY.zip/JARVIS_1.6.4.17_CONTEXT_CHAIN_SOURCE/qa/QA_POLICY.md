# Zorunlu QA
1. Gradle release derlemesi başarılı olmalı.
2. D8/R8 tarafından oluşturulan DEX dışında manuel DEX düzenlemesi yasak.
3. APK imza sertifikası production SHA-256 ile eşleşmeli.
4. `apkanalyzer`/`dexdump` veya ART tabanlı doğrulamada VerifyError olmamalı.
5. Alarm parser regresyonu 1694/1694 geçmeli.
6. Wake-word testi geçmeli.
7. Fiziksel vivo cihazda cold launch testi geçmeden sürüm tamam sayılmamalı.
