from pathlib import Path
root=Path(__file__).resolve().parents[1]
hybrid=(root/'app/src/main/java/com/hakan/jarvis/HybridActivity.java').read_text(encoding='utf8')
phone=(root/'app/src/main/java/com/hakan/jarvis/PhoneActions.java').read_text(encoding='utf8')
voice=(root/'app/src/main/java/com/hakan/jarvis/VoiceController.java').read_text(encoding='utf8')
checks={
 'completion_callback': 'mp.setOnCompletionListener' in voice and 'complete(job)' in voice,
 'after_only_in_complete': voice.count('job.after.run()')==1,
 'app': '"app_open",new Runnable(){public void run()' in phone,
 'alarm': '"alarm_schedule",new Runnable(){public void run()' in phone,
 'torch': 'host.say("",c.enabled?"torch_on":"torch_off",new Runnable(){public void run()' in phone,
 'permission': '"torch_permission",new Runnable(){public void run()' in phone,
 'legacy_capture': 'capturingAction=true;super.onActivityResult(101,RESULT_OK,data)' in hybrid,
 'legacy_deferred': 'deferredAction=new Runnable(){public void run(){HybridActivity.super.startActivity(intent);}' in hybrid,
}
for k,v in checks.items():
    assert v,k
print(f'TOTAL {len(checks)} PASS')
