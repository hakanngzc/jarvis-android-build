import com.hakan.jarvis.*;import java.util.*;
public class UnderstandingTest {
 static int count;static void ok(boolean v,String s){if(!v)throw new AssertionError(s);count++;}
 static void at(String s,int h,int m){PhoneCommand c=PhoneCommand.parse(s);ok(c!=null&&c.error==null&&c.hour==h&&c.minute==m,s+" => "+(c==null?"null":c.error+" "+c.hour+":"+c.minute));}
 static void bad(String s){PhoneCommand c=PhoneCommand.parse(s);ok(c!=null&&c.error!=null,"reject "+s);}
 public static void main(String[] a){
 at("alarmımı sabah yediye ayarla",7,0);at("07 30 alarm kur",7,30);ok(PhoneCommand.parse("Spotify aç.")!=null,"punctuated app");
 at("alarmı sabah yedi otuz kurar mısın",7,30);at("sabah yedi buçuğa alarm kur",7,30);at("Lütfen akşam on bir kırk beşe alarm kur",23,45);at("Beni sabah altıda uyandır",6,0);at("Beni sabah altıda uyandırır mısın",6,0);at("alarmı 19.30'a ayarlar mısın",19,30);at("Sabah sekizi çeyrek geçe alarm kur",8,15);at("Sabah sekize çeyrek kala alarm kur",7,45);at("gece on ikiye çeyrek kala alarm kur",23,45);at("sabah sekizi on geçe alarm kur",8,10);at("akşam 19:30 için alarm ayarla",19,30);at("öğlen bir buçuk alarm kur",13,30);at("alarm kur 07:30",7,30);at("alarmı sabah on bir yirmi beşe kur",11,25);at("sabah yediye bir alarm kur",7,0);
 bad("alarmı yedi otuz kur");bad("alarm kur");bad("25:10 alarm kur");at("yarın sabah yedi alarm kur",7,0);bad("sabah akşam yedi alarm kur");bad("7 ve 8 alarm kur");bad("alarmı kurma");bad("sabah yediye alarm kur sonra sekize");
 ok(AlarmTime.parse("alarm kur").question.equals("time"),"ask time");ok(AlarmTime.parse("yedi otuz alarm kur").question.equals("period"),"ask AM PM");
 ok(PhoneCommand.parse("YouTube'u açar mısın").target.equals("youtube"),"polite app");ok(PhoneCommand.parse("telefonun ışığını açabilir misin").enabled,"polite torch");ok(!PhoneCommand.parse("el fenerini kapatır mısın").enabled,"polite off");ok(PhoneCommand.parse("not et sabah yedide feneri aç")==null,"note protected");ok(CommandLanguage.canonical("not et Şule'yi ara").equals("not al Şule'yi ara"),"note original spelling preserved");
 ok(CommandLanguage.conflict(Arrays.asList("feneri aç","feneri kapat")),"conflicting alternatives require choice");ok(!CommandLanguage.conflict(Arrays.asList("feneri aç","feneri açar mısın")),"same intent alternatives agree");
 for(int h=0;h<24;h++)for(int m:new int[]{0,5,15,30,45,59})at(String.format(Locale.US,"%02d:%02d alarm kur",h,m),h,m);
 System.out.println("TOTAL "+count+" PASS");
 }
}
