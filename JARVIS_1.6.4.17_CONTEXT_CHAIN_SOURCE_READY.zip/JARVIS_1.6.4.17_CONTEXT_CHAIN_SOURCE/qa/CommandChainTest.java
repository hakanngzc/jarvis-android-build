package com.hakan.jarvis;
import java.util.*;
public final class CommandChainTest {
 static int pass,fail;
 static void check(boolean b,String n){if(b){pass++;}else{fail++;System.out.println("FAIL "+n);}}
 static void chain(String s,String a,String b){CommandChain.Result r=CommandChain.parse(s);check(r.error==null&&r.commands.size()==2&&r.commands.get(0).equals(a)&&r.commands.get(1).equals(b),s);}
 static void single(String s){CommandChain.Result r=CommandChain.parse(s);check(r.error==null&&r.commands.size()==1,s);}
 public static void main(String[] x){
  chain("Spotify aç sonra sesi biraz yükselt","Spotify aç","sesi biraz yükselt");
  chain("feneri aç ve sonra saat kaç","feneri aç","saat kaç");
  chain("YouTube gir ardından feneri aç","YouTube gir","feneri aç");
  chain("yarın sabah 8'e alarm kur sonra Spotify aç","yarın sabah 8'e alarm kur","Spotify aç");
  single("20 dakika sonra alarm kur");
  single("iki saat sonra alarm kur");
  single("yarım saat sonra alarm kur");
  single("Spotify aç");
  CommandChain.Result r=CommandChain.parse("feneri aç sonra Spotify aç sonra saat kaç");check(r.error!=null,"three-step rejected");
  check(CommandChain.parse("sonra Spotify aç").error!=null,"missing first rejected");
  System.out.println("TOTAL "+(pass+fail)+" PASS "+pass+" FAIL "+fail);if(fail>0)System.exit(1);
 }
}
