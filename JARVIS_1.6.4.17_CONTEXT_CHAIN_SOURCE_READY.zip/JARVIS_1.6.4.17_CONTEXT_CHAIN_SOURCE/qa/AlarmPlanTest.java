import com.hakan.jarvis.*;import java.util.*;
public class AlarmPlanTest {
 static int count;static TimeZone tr=TimeZone.getTimeZone("Europe/Istanbul");static void ok(boolean b,String s){if(!b)throw new AssertionError(s);count++;}
 static long date(TimeZone z,int y,int mo,int d,int h,int m){Calendar c=Calendar.getInstance(z);c.clear();c.set(y,mo-1,d,h,m,0);return c.getTimeInMillis();}
 static void expect(String s,long now,long expected,TimeZone z){AlarmPlan p=AlarmPlan.parse(s,now,z);ok(p.error==null&&p.when==expected,s+" => "+p.error+" "+new Date(p.when)+" expected "+new Date(expected));}
 public static void main(String[] args){long now=date(tr,2026,9,26,23,36);
 expect("Jarvis yarın saat 8.30'a alarm kurar mısın",now,date(tr,2026,9,27,8,30),tr);
 expect("Yarın sabah sekiz buçuğa alarm kur",now,date(tr,2026,9,27,8,30),tr);
 expect("öğleden sonra üçe alarm kur",now,date(tr,2026,9,27,15,0),tr);
 expect("20 dakika sonra alarm kur",now,now+20*60000,tr);expect("iki saat otuz dakika sonra alarm kur",now,now+150*60000,tr);
 expect("pazartesi 08:30 alarm kur",now,date(tr,2026,9,28,8,30),tr);
 expect("cumartesi 08:30 alarm kur",now,date(tr,2026,10,3,8,30),tr);
 expect("08:30 alarm kur",now,date(tr,2026,9,27,8,30),tr);
 expect("yarın 08:30 alarm kur",date(tr,2026,9,26,1,0),date(tr,2026,9,27,8,30),tr);
 expect("yarın 00:00 alarm kur",date(tr,2026,12,31,23,59),date(tr,2027,1,1,0,0),tr);
 expect("yarın 08:30 alarm kur",date(tr,2028,2,28,12,0),date(tr,2028,2,29,8,30),tr);
 expect("bugün 23:59 alarm kur",now,date(tr,2026,9,26,23,59),tr);
 ok(AlarmPlan.parse("bugün 08:30 alarm kur",now,tr).question.equals("date"),"past today asks date");
 ok(AlarmPlan.parse("yarın alarm kur",now,tr).context.equals("yarin"),"missing time preserves tomorrow");
 ok(AlarmPlan.parse("yarın yedi otuz alarm kur",now,tr).question.equals("period"),"spoken ambiguous period asks");
 for(String s:new String[]{"bugün yarın 08:30 alarm kur","yarın 25:00 alarm kur","yarın 07:61 alarm kur","sıfır dakika sonra alarm kur","eksi iki saat sonra alarm kur","her gün 08:30 alarm kur","yarın 8 ve 9 alarm kur","20 dakika sonra ve yarın alarm kur","alarm kurma"})ok(AlarmPlan.parse(s,now,tr).error!=null,"reject "+s);
 for(int h=0;h<24;h++)for(int m=0;m<60;m++)expect(String.format(Locale.US,"yarın %02d:%02d alarm kur",h,m),now,date(tr,2026,9,27,h,m),tr);
 for(int month=1;month<=12;month++){Calendar c=Calendar.getInstance(tr);c.clear();c.set(2026,month-1,1,23,55);c.set(Calendar.DAY_OF_MONTH,c.getActualMaximum(Calendar.DAY_OF_MONTH));long start=c.getTimeInMillis();c.add(Calendar.DAY_OF_YEAR,1);c.set(Calendar.HOUR_OF_DAY,8);c.set(Calendar.MINUTE,30);expect("yarın 08:30 alarm kur",start,c.getTimeInMillis(),tr);}
 TimeZone berlin=TimeZone.getTimeZone("Europe/Berlin");expect("yarın 08:30 alarm kur",date(berlin,2026,3,28,12,0),date(berlin,2026,3,29,8,30),berlin);ok(AlarmPlan.parse("yarın 02:30 alarm kur",date(berlin,2026,3,28,12,0),berlin).error!=null,"nonexistent DST time rejected");
 expect("yarın 08:30 alarm kur",date(berlin,2026,10,24,12,0),date(berlin,2026,10,25,8,30),berlin);
 ok(AlarmTime.parse("sabah 1 5 alarm kur").hour==1&&AlarmTime.parse("sabah 1 5 alarm kur").minute==5,"digit groups not concatenated into 15 hours");
 ok(CommandLanguage.conflict(Arrays.asList("yarın 08:30 alarm kur","08:30 alarm kur")),"different date hypotheses flagged");
 ok(AlarmPlan.parse("02:30 alarm kur",date(berlin,2026,3,28,12,0),berlin).error!=null,"next occurrence DST gap must not shift clock silently");
 System.out.println("TOTAL "+count+" PASS");
 }
}
