from pathlib import Path
root=Path(__file__).resolve().parents[1]
activity=(root/'app/src/main/java/com/hakan/jarvis/HybridActivity.java').read_text(encoding='utf8')
engine=(root/'app/src/main/java/com/hakan/jarvis/HybridEngine.java').read_text(encoding='utf8')
recog=(root/'app/src/main/java/com/hakan/jarvis/RecognitionConfig.java').read_text(encoding='utf8')
checks={
 'force_offline_short_circuit': 'prefs!=null&&prefs.getBoolean("force_offline",false))return false;' in activity,
 'validated_network_required': 'NET_CAPABILITY_INTERNET' in activity and 'NET_CAPABILITY_VALIDATED' in activity,
 'local_time_stays_local': 'if(r.kind.equals("time")){local(' in activity,
 'local_date_stays_local': 'if(r.kind.equals("date")){local(' in activity,
 'local_calc_stays_local': 'if(r.kind.equals("calc")){try{local(' in activity,
 'local_notes_stay_local': 'if(r.kind.equals("note"))' in activity and 'if(r.kind.equals("notes"))' in activity,
 'only_data_kinds_use_request': 'if(r.kind.equals("weather")||r.kind.equals("currency")||r.kind.equals("wiki")){request(r);return;}' in activity,
 'offline_uses_cache_first': 'if(!online){Answer a=cached(r,now);if(a!=null)return a;throw new Unavailable(' in engine,
 'online_failure_falls_back_cache': 'Answer a=cached(r,now);if(a!=null){a.cached=true;return a;}' in engine,
 'offline_missing_never_invents': 'Çevrimdışısınız. Bu sorgu için kayıtlı veri yok.' in engine,
 'only_https_data_endpoints': 'http://' not in engine and engine.count('https://')>=4,
 'network_request_cancellable': 'public void cancel(){HttpURLConnection c=active;if(c!=null)c.disconnect();}' in engine,
 'new_command_cancels_previous_work': 'cancelWork();last=null;updateHybridStatus();' in activity and 'cancelWork();last=r;' in activity,
 'bounded_ui_timeout': 'handler.postDelayed(timeout,18000);' in activity,
 'speech_recognition_prefers_offline_when_offline': 'RecognizerIntent.EXTRA_PREFER_OFFLINE,offline' in recog and 'RecognitionConfig.intent(!isOnline())' in activity,
 'cached_results_labeled': 'KAYITLI VERİ' in activity and 'GÜNCELLİĞİNİ YİTİRMİŞ OLABİLİR' in activity,
}
for k,v in checks.items(): print(k, 'PASS' if v else 'FAIL')
assert all(checks.values())
print(f'TOTAL {sum(checks.values())}/{len(checks)} PASS')
