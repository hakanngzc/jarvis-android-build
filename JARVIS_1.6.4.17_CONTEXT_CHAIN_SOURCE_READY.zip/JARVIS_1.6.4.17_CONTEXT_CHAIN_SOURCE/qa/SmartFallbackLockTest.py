from pathlib import Path
root=Path(__file__).resolve().parents[1]
h=(root/'app/src/main/java/com/hakan/jarvis/HybridActivity.java').read_text(encoding='utf8')
r=(root/'app/src/main/java/com/hakan/jarvis/VoiceReplies.java').read_text(encoding='utf8')
c=(root/'app/src/main/java/com/hakan/jarvis/RecognitionConfig.java').read_text(encoding='utf8')
p=(root/'app/src/main/assets/voice/phrases.json').read_text(encoding='utf8')
checks={
'unknown_no_action':'say("",key,(key.equals("clarify")||key.equals("unknown"))?null:action);return;' in h,
'multiple_choice':'setTitle("Hangisini söylediniz?")' in h,
'relisten':'Yeniden dinle' in h and 'Tekrar dinle' in h,
'low_confidence':'scores[0]>=0&&scores[0]<0.55f' in h and 'Doğru mu duydum?' in h,
'unknown_key':'return "unknown";' in r,
'clarify_key':'return "clarify";' in r,
'no_match_retry':'case 7:return "Ses duyuldu ama sözcükler çözülemedi.' in c,
'voice_prompts':all(('"'+k+'"') in p for k in ('unknown','clarify','speech_choose')),
}
for k,v in checks.items(): print(k,'PASS' if v else 'FAIL')
assert all(checks.values())
