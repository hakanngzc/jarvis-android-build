# 1.6.4.7 MIC SAFE yöntemi

Telefonda çalışan çekirdeğin DEX yapısı büyütülmedi. RecognitionConfig.intent içindeki sayısal operandlar aynı instruction biçiminde değiştirildi. String_data eklenmedi, offset/padding değişmedi. Zorunlu minimum konuşma süresi için yapılan putExtra çağrısı, tam aynı 5 code-unit alanında NOP'lanarak kaldırıldı; başka Intent-extra anahtarı yeniden kullanılmadı. Gelecekte temiz Gradle/D8 build yapılırken kaynak kod bu davranışı doğrudan uygular.
