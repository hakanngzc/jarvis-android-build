# JARVIS 1.6.4.16 HYBRID ROUTER SAFE

- package: `com.hakan.jarvis`
- versionCode: `81`
- versionName: `1.6.4.16-hybrid-safe01`
- production certificate SHA-256: `F2:4F:05:32:8D:0D:A5:5A:60:53:BD:31:22:17:40:86:42:5E:A7:3B:EC:91:76:92:2E:13:44:CD:B1:E8:30:8A`

Bu release 1.6.4.15'in runtime davranışını korur. Yeni iş, hybrid online/offline router sözleşmesini zorunlu QA ile kilitlemektir. Detaylar `HYBRID_ROUTER_LOCK_METHOD.md` ve `JARVIS_1.6.4.16_HYBRID_ROUTER_SAFE_QA.txt` içindedir.

Önceki sürümlerin yöntem belgeleri kaynak pakette korunmuştur.
