# JARVIS 1.6.4.9 VOICE SAFE

- Base: 1.6.4.8 NATURAL SAFE
- Ses motoru: tr-TR-AhmetNeural korunur.
- Konuşma hızı: -7% -> -4%.
- Pitch: -4Hz -> -2Hz.
- Android TextToSpeech eklenmedi.
- Çevrimdışı MP3 ses bankası değiştirilmedi.
- APK DEX yaması sadece eşit uzunluklu iki voice string slotunda yapılır.
- DEX boyutu, string offsetleri, padding ve opcode alanları değiştirilmez.
