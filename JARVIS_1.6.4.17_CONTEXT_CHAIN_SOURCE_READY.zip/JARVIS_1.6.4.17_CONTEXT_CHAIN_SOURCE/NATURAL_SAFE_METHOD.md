# 1.6.4.8 NATURAL SAFE yöntemi

- Torch normalization regex: 70 -> 70 byte
- App open regex: 56 -> 56 byte
- Yeni string_data kaydı yok
- DEX section boyutu değişmedi
- Opcode/code item değişmedi
- String-id sıralaması ve string_data offsetleri doğrulandı

Amaç: doğal komutları genişletirken 1.6.4.7'nin açılan runtime çekirdeğini bozmamak.
