# JARVIS 1.6.4.16 HYBRID ROUTER SAFE

Bu sürüm, 1.6.4.15 üzerindeki mevcut hibrit yönlendirme davranışını yeniden yazmaz. Çalışan runtime çekirdeği korunur ve aşağıdaki sözleşme zorunlu QA olarak kilitlenir:

- Saat, tarih, hesap, notlar, bağlantı durumu ve yardım komutları yerelde kalır.
- Yalnız hava durumu, kur ve Wikipedia/bilgi sorguları hybrid veri isteğine girer.
- Force-offline, bağlantı olsa bile ağ yolunu kapatır.
- Android bağlantısı ancak INTERNET + VALIDATED capability ile online kabul edilir.
- Offline veri sorgusunda önce tarihli cache aranır; cache yoksa bilgi uydurulmaz.
- Online servis hatasında cache varsa ona düşülür.
- Veri uçları HTTPS'tir.
- Aktif HTTP isteği iptal edilebilir; yeni komut önceki işi iptal eder.
- UI timeout'u sınırlıdır.
- Offline modda ses tanıma isteği offline recognition tercih eder.
- Cache/stale cevaplar ekranda açıkça işaretlenir.

Runtime DEX davranışı 1.6.4.15 ile aynıdır. APK'da yalnız sürüm etiketi/manifest sürüm bilgisi değişir; imza aynı production sertifikasıyla yapılır.
