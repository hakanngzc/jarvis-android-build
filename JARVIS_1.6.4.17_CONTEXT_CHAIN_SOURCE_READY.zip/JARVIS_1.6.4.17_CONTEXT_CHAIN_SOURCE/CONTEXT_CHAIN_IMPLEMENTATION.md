# JARVIS 1.6.4.17 CONTEXT CHAIN SAFE

Source implementation is complete. Runtime APK has **not** been rebuilt yet because the current execution container has no Android SDK/D8 and outbound SDK downloads are DNS-blocked.

## Implemented source behavior
- Recognizes `sonra`, `ve sonra`, `ardından`.
- `20 dakika sonra alarm kur`, `iki saat sonra alarm kur`, `yarım saat sonra alarm kur` remain single alarm commands.
- Maximum two commands per chain in v1.
- First step is deliberately restricted to safe in-app/local/data commands or torch. App launch may be the second step.
- Second command is released only by the real voice-completion callback of a successful terminal first-step response. No fixed timer is used.
- Known failures clear the pending second command.
- New user input, app pause, and SESİ DURDUR clear the pending chain.
- Existing CONFIRM-FIRST and SMART FALLBACK contracts remain in force.

## Examples intended for v1 runtime
- `feneri aç sonra Spotify aç`
- `saat kaç sonra YouTube aç`
- `dolar kuru sonra notlarımı göster`
- `Kahramanmaraş hava durumu ardından Spotify aç`

## Deliberately not enabled in v1
- `Spotify aç sonra sesi yükselt`: launching an external app pauses JARVIS, so app-open as the first step is deferred to the next chain iteration rather than using an unsafe race.
- Three or more actions in one sentence.
