from pathlib import Path
import zipfile, struct, hashlib, zlib, shutil, subprocess, re, importlib.util
BASE=Path('/mnt/data/JARVIS_1.6.4.12_APP_COMMAND_SAFE.apk')
OUT=Path('/mnt/data/JARVIS_1.6.4.13_FUZZY_SAFE.apk')
QA=Path('/mnt/data/JARVIS_1.6.4.13_FUZZY_SAFE_QA.txt')
WORK=Path('/mnt/data/j16413/build'); shutil.rmtree(WORK,ignore_errors=True); WORK.mkdir(parents=True)
KEYDIR=Path('/mnt/data/j1641/private/JARVIS_BUILD_KEYS')
HELPER='/mnt/data/jarvis1641/src/build_v1641_speech_stability.py'
spec=importlib.util.spec_from_file_location('h',HELPER); h=importlib.util.module_from_spec(spec); spec.loader.exec_module(h); EXPECTED=h.EXPECTED_CERT

def u32(b,o): return struct.unpack_from('<I',b,o)[0]
def uleb(b,o):
    r=s=0;p=o
    while True:
        x=b[p];p+=1;r|=(x&127)<<s
        if not x&128:return r,p
        s+=7

def entries(b):
    n,so=u32(b,56),u32(b,60); out=[]
    for i in range(n):
        off=u32(b,so+4*i); ln,p=uleb(b,off); q=b.index(0,p)
        out.append({'idx':i,'off':off,'data':p,'end':q,'len':ln,'text':bytes(b[p:q]).decode('utf-8','replace')})
    return out

def badsort(b):
    e=entries(b); return [(i,e[i]['text'],e[i+1]['text']) for i in range(len(e)-1) if e[i]['text']>=e[i+1]['text']]
def gaps(b):
    e=entries(b); return [(i,e[i+1]['off']-(e[i]['end']+1)) for i in range(len(e)-1) if e[i+1]['off']!=(e[i]['end']+1)]

with zipfile.ZipFile(BASE) as z:
    assert z.testzip() is None
    dex=bytearray(z.read('classes.dex'))
    manifest=bytearray(z.read('AndroidManifest.xml'))
base_dex=bytes(dex); E=entries(dex); found={x['text']:x for x in E}

patches=[
 ('youtube(?:u|yu)?','youtube?|yutub.?'),
 ('spotify(?:i|yi)?','spotify?|spotif.'),
 ('whatsapp(?:i|u)?','whatsapp?|vatsap'),
 ('instagram(?:i)?','instagram?(i)?$'),
]
changes=[]
for old,new in patches:
    assert old in found, old
    e=found[old]
    assert len(old.encode('ascii'))==len(new.encode('ascii'))==e['end']-e['data'],(old,new,len(old),len(new),e['end']-e['data'])
    dex[e['data']:e['end']]=new.encode('ascii')
    changes.append((e,old,new))

# visible banner same UTF-8 byte length
E2=entries(dex)
banner_old='JARVIS 1.6.4.12· SYSTEM ALARM'
banner_new='JARVIS 1.6.4.13· SYSTEM ALARM'
assert len(banner_old.encode('utf8'))==len(banner_new.encode('utf8'))
be=[x for x in E2 if x['text']==banner_old]; assert len(be)==1,[x['text'] for x in E2 if 'JARVIS 1.6.4' in x['text']][:10]
be=be[0]; dex[be['data']:be['end']]=banner_new.encode('utf8')
# DEX header
sig=hashlib.sha1(dex[32:]).digest(); dex[12:32]=sig; struct.pack_into('<I',dex,8,zlib.adler32(dex[12:]) & 0xffffffff)
new_dex=bytes(dex)
assert len(new_dex)==len(base_dex)==683080
assert gaps(new_dex)==[], gaps(new_dex)[:5]
assert badsort(new_dex)==[], badsort(new_dex)[:5]
assert hashlib.sha1(new_dex[32:]).digest()==new_dex[12:32]
assert (zlib.adler32(new_dex[12:])&0xffffffff)==u32(new_dex,8)
allowed=set(range(8,32))
for e,_,_ in changes: allowed.update(range(e['data'],e['end']))
allowed.update(range(be['data'],be['end']))
diffs=[i for i,(a,b) in enumerate(zip(base_dex,new_dex)) if a!=b]
unexpected=[i for i in diffs if i not in allowed]
assert not unexpected, unexpected[:20]

# manifest same-length versionName + versionCode 77 -> 78
old_v='1.6.4.12-apps-safe0001'.encode('utf-16le')
new_v='1.6.4.13-fuzzy-safe001'.encode('utf-16le')
assert len(old_v)==len(new_v) and manifest.count(old_v)==1
p=manifest.find(old_v); manifest[p:p+len(old_v)]=new_v

def u16m(o):return struct.unpack_from('<H',manifest,o)[0]
def u32m(o):return struct.unpack_from('<I',manifest,o)[0]
strings=[];pos=8;patched=False
while pos<len(manifest):
    typ=u16m(pos);hs=u16m(pos+2);sz=u32m(pos+4);assert sz>0
    if typ==1:
        count=u32m(pos+8);flags=u32m(pos+16);st=u32m(pos+20);base=pos+st;offs=[u32m(pos+hs+4*i) for i in range(count)];utf8=bool(flags&0x100)
        def l8(q):
            x=manifest[q];return ((((x&127)<<8)|manifest[q+1],2) if x&128 else (x,1))
        def l16(q):
            x=u16m(q);return ((((x&0x7fff)<<16)|u16m(q+2),4) if x&0x8000 else (x,2))
        strings=[]
        for so in offs:
            q=base+so
            if utf8:
                _,k=l8(q);q+=k;bl,k=l8(q);q+=k;strings.append(bytes(manifest[q:q+bl]).decode('utf8','replace'))
            else:
                ln,k=l16(q);q+=k;strings.append(bytes(manifest[q:q+ln*2]).decode('utf-16le','replace'))
    elif typ==0x0102 and strings and strings[u32m(pos+20)]=='manifest':
        ast=u16m(pos+24);asz=u16m(pos+26);ac=u16m(pos+28);a0=pos+16+ast
        for i in range(ac):
            a=a0+i*asz;nm=strings[u32m(a+4)];tv=manifest[a+15]
            if nm=='versionCode' and tv==0x10:
                vc=u32m(a+16); assert vc==77,vc; struct.pack_into('<I',manifest,a+16,78); patched=True
    pos+=sz
assert patched
new_manifest=bytes(manifest)
info=h.parse_axml_info(new_manifest)
assert info['package']=='com.hakan.jarvis' and info['versionCode']==78 and info['versionName']=='1.6.4.13-fuzzy-safe001',info

# repack
unsigned=WORK/'unsigned.apk'
with zipfile.ZipFile(BASE) as zin, zipfile.ZipFile(unsigned,'w',allowZip64=False) as zout:
    for zi0 in zin.infolist():
        if zi0.filename.startswith('META-INF/'): continue
        data=zin.read(zi0.filename)
        if zi0.filename=='classes.dex': data=new_dex
        elif zi0.filename=='AndroidManifest.xml': data=new_manifest
        zi=zipfile.ZipInfo(zi0.filename,zi0.date_time); zi.compress_type=zi0.compress_type; zi.comment=zi0.comment; zi.extra=zi0.extra; zi.internal_attr=zi0.internal_attr; zi.external_attr=zi0.external_attr; zi.create_system=zi0.create_system; zi.flag_bits=zi0.flag_bits&~0x8
        zout.writestr(zi,data)

# sign v1 + v2
vals=h.load_signing(KEYDIR); v1=WORK/'v1.apk'; shutil.copy2(unsigned,v1)
r=subprocess.run(['jarsigner','-keystore',str(KEYDIR/'jarvis-release.jks'),'-storepass',vals['storepass'],'-keypass',vals['keypass'],'-sigalg','SHA256withRSA','-digestalg','SHA-256',str(v1),vals['alias']],capture_output=True,text=True); assert r.returncode==0,r.stdout+r.stderr
from cryptography.hazmat.primitives.serialization import pkcs12,Encoding,PublicFormat
p12=WORK/'r.p12'; r=subprocess.run(['keytool','-importkeystore','-noprompt','-srckeystore',str(KEYDIR/'jarvis-release.jks'),'-srcstoretype','JKS','-srcstorepass',vals['storepass'],'-srckeypass',vals['keypass'],'-srcalias',vals['alias'],'-destkeystore',str(p12),'-deststoretype','PKCS12','-deststorepass',vals['storepass'],'-destkeypass',vals['keypass'],'-destalias',vals['alias']],capture_output=True,text=True); assert r.returncode==0,r.stdout+r.stderr
key,cert,_=pkcs12.load_key_and_certificates(p12.read_bytes(),vals['storepass'].encode()); p12.unlink(missing_ok=True)
cert_der=cert.public_bytes(Encoding.DER); pub_der=key.public_key().public_bytes(Encoding.DER,PublicFormat.SubjectPublicKeyInfo)
OUT.write_bytes(h.add_v2(v1.read_bytes(),key,cert_der,pub_der))

# final integrity/signature verify
with zipfile.ZipFile(OUT) as z:
    assert z.testzip() is None
    dd=z.read('classes.dex'); assert len(dd)==683080 and gaps(dd)==[] and badsort(dd)==[]
    assert hashlib.sha1(dd[32:]).digest()==dd[12:32]
    assert (zlib.adler32(dd[12:])&0xffffffff)==u32(dd,8)
    assert z.read('AndroidManifest.xml')==new_manifest
    with zipfile.ZipFile(BASE) as zb:
        names=set(z.namelist())|set(zb.namelist())
        pd=[n for n in names if (n not in z.namelist() or n not in zb.namelist() or z.read(n)!=zb.read(n)) and not n.startswith('META-INF/')]
        assert sorted(pd)==['AndroidManifest.xml','classes.dex'],pd
rv=subprocess.run(['jarsigner','-verify','-certs',str(OUT)],capture_output=True,text=True); assert rv.returncode==0 and 'jar verified' in (rv.stdout+rv.stderr).lower()
fp=h.verify_v2(OUT); assert fp==EXPECTED,(fp,EXPECTED)
ct=subprocess.run(['keytool','-printcert','-jarfile',str(OUT)],capture_output=True,text=True,check=True).stdout
m=re.search(r'SHA256:\s*([0-9A-F:]+)',ct,re.I); jarfp=m.group(1).upper(); assert jarfp==EXPECTED

# exact fuzzy alias behavior tests
js=WORK/'FuzzyAlias.java'
js.write_text(r'''public class FuzzyAlias{static int n=0;static void ok(boolean b,String s){if(!b)throw new AssertionError(s);n++;}static String pkg(String a){a=a.replace(" ","").replaceFirst("'(yi|yu|i|u)$","");if(a.matches("youtube?|yutub.?"))return "youtube";if(a.matches("spotify?|spotif."))return "spotify";if(a.matches("whatsapp?|vatsap"))return "whatsapp";if(a.matches("instagram?(i)?$"))return "instagram";return null;}public static void main(String[]x){String[][] yes={{"youtube","youtube"},{"youtub","youtube"},{"yutub","youtube"},{"yutube","youtube"},{"spotify","spotify"},{"spotif","spotify"},{"spotifi","spotify"},{"spotifa","spotify"},{"whatsapp","whatsapp"},{"whatsap","whatsapp"},{"vatsap","whatsapp"},{"instagram","instagram"},{"instagra","instagram"},{"instagrami","instagram"},{"instagram'i","instagram"}};for(String[]p:yes)ok(p[1].equals(pkg(p[0])),p[0]+" -> "+pkg(p[0]));for(String s:new String[]{"youtubeabc","spotifxx","whats","vatsa","inst","camera","telegram"})ok(pkg(s)==null,"reject "+s+" got "+pkg(s));System.out.println("TOTAL "+n+" PASS");}}''',encoding='utf8')
subprocess.run(['javac',str(js)],cwd=WORK,check=True,capture_output=True,text=True)
rr=subprocess.run(['java','-cp',str(WORK),'FuzzyAlias'],capture_output=True,text=True,check=True); assert 'TOTAL 22 PASS' in rr.stdout,rr.stdout

# previous app command test from source
srcroot=Path('/mnt/data/j16413/src/JARVIS_1.6.4.12_APP_COMMAND_SAFE_SOURCE')
app_test=srcroot/'qa/AppCommandNaturalTest.java'
rt0=subprocess.run(['javac',str(app_test)],cwd=WORK,capture_output=True,text=True)
# javac writes near source when absolute; instead compile copied test
shutil.copy2(app_test,WORK/'AppCommandNaturalTest.java')
subprocess.run(['javac','AppCommandNaturalTest.java'],cwd=WORK,check=True,capture_output=True,text=True)
ra=subprocess.run(['java','-cp',str(WORK),'AppCommandNaturalTest'],capture_output=True,text=True,check=True); assert 'TOTAL 17 PASS' in ra.stdout or 'TOTAL 18 PASS' in ra.stdout,ra.stdout

# existing regression suite
rt=subprocess.run(['python','/mnt/data/j1641/tests/test_alarm_parser.py'],cwd='/mnt/data/j1641',capture_output=True,text=True); txt=rt.stdout+rt.stderr
assert rt.returncode==0 and 'TOTAL 1482 PASS' in txt and 'TOTAL 33 PASS' in txt and 'TOTAL 179 PASS' in txt,txt[-3000:]
sha=hashlib.sha256(OUT.read_bytes()).hexdigest()
QA.write_text('\n'.join([
'JARVIS 1.6.4.13 FUZZY COMMAND SAFE','='*40,
'Base: JARVIS 1.6.4.12 APP COMMAND SAFE',
'Change scope: conservative ASR-tolerant aliases for known app names only.',
'',
'Accepted alias families:',
'- YouTube: youtube / youtub / yutub / yutube-like one-char tail',
'- Spotify: spotify / spotif / spotifi / spotifa-like one-char tail',
'- WhatsApp: whatsapp / whatsap / vatsap',
'- Instagram: instagram / instagra / instagrami',
'',
'Safety behavior:',
'- Fuzzy matching is limited to explicit app-open commands already parsed as app intents.',
'- Alarm, torch, time/date, notes, wake-word, microphone and voice logic unchanged.',
'- Unknown/too-short names are not converted to known app aliases.',
'',
'Previous features retained:',
'- wake-word tolerance','- alarm improvements','- microphone listening improvements','- natural torch commands','- time/date natural commands','- notes natural commands','- app command variants','- neural voice tuning',
'',
'Package: com.hakan.jarvis','VersionCode: 78','VersionName: 1.6.4.13-fuzzy-safe001',
'',
'QA:',
'- DEX length unchanged: 683080 bytes PASS',
'- 4 alias regexes replaced at exact byte length PASS',
'- New string_data items: 0 PASS',
'- DEX string_data gaps: 0 PASS',
'- DEX string-id order: PASS',
'- DEX SHA-1: PASS','- DEX Adler32: PASS',
'- Unexpected DEX byte changes outside header/4 alias strings/banner: 0 PASS',
'- APK payload changes vs 1.6.4.12: AndroidManifest.xml + classes.dex only PASS',
'- ZIP CRC: PASS','- JAR/v1 signature: PASS','- APK v2 signature/content digest: PASS','- Production certificate: MATCH',
'- New fuzzy-alias behavior tests: 22/22 PASS',
'- Previous app-command behavior test: PASS',
'- Alarm regression: 1482/1482 PASS','- Phone command regression: 33/33 PASS','- Understanding regression: 179/179 PASS',
'',f'APK SHA-256: {sha}',f'Certificate SHA-256: {jarfp}',
'', 'Physical-device launch remains the final runtime validation.'
]),encoding='utf8')
print('OUT',OUT,OUT.stat().st_size);print('SHA',sha);print('CERT',jarfp);print(rr.stdout.strip());print(ra.stdout.strip());print('REGRESSION 1694/1694 PASS');print('DIFFS',len(diffs),'UNEXPECTED',len(unexpected))
