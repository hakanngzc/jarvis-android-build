from pathlib import Path
import zipfile, struct, hashlib, zlib, shutil, subprocess, re, importlib.util
BASE=Path('/mnt/data/j16415/JARVIS_1.6.4.14.apk')
OUT=Path('/mnt/data/JARVIS_1.6.4.15_SMART_FALLBACK_SAFE.apk')
QA=Path('/mnt/data/JARVIS_1.6.4.15_SMART_FALLBACK_SAFE_QA.txt')
WORK=Path('/mnt/data/j16415/build'); shutil.rmtree(WORK,ignore_errors=True); WORK.mkdir(parents=True)
SRCROOT=Path('/mnt/data/j16415/src/JARVIS_1.6.4.14_CONFIRM_FIRST_SAFE_SOURCE')
KEYDIR=Path('/mnt/data/j1641/private/JARVIS_BUILD_KEYS')
HELPER='/mnt/data/jarvis1641/src/build_v1641_speech_stability.py'
spec=importlib.util.spec_from_file_location('h',HELPER); h=importlib.util.module_from_spec(spec); spec.loader.exec_module(h); EXPECTED=h.EXPECTED_CERT

def u32(b,o): return struct.unpack_from('<I',b,o)[0]
def uleb(b,o):
    r=s=0;p=o
    while True:
        x=b[p];p+=1;r|=(x&127)<<s
        if not x&128:return r,p
        s+=7

def entries(b):
    n,so=u32(b,56),u32(b,60); out=[]
    for i in range(n):
        off=u32(b,so+4*i); ln,p=uleb(b,off); q=b.index(0,p)
        out.append({'idx':i,'off':off,'data':p,'end':q,'len':ln,'text':bytes(b[p:q]).decode('utf-8','replace')})
    return out

def badsort(b):
    e=entries(b); return [(i,e[i]['text'],e[i+1]['text']) for i in range(len(e)-1) if e[i]['text']>=e[i+1]['text']]
def gaps(b):
    e=entries(b); return [(i,e[i+1]['off']-(e[i]['end']+1)) for i in range(len(e)-1) if e[i+1]['off']!=(e[i]['end']+1)]

# SMART FALLBACK source lock checks. The behavior already exists; this release locks it without rewriting runtime code.
hybrid=(SRCROOT/'app/src/main/java/com/hakan/jarvis/HybridActivity.java').read_text(encoding='utf8')
replies=(SRCROOT/'app/src/main/java/com/hakan/jarvis/VoiceReplies.java').read_text(encoding='utf8')
recog=(SRCROOT/'app/src/main/java/com/hakan/jarvis/RecognitionConfig.java').read_text(encoding='utf8')
phrases=(SRCROOT/'app/src/main/assets/voice/phrases.json').read_text(encoding='utf8')
checks={
 'unknown_has_no_action': 'say("",key,(key.equals("clarify")||key.equals("unknown"))?null:action);return;' in hybrid,
 'unknown_key_detected': 'if(s.contains("islem yok"))return "unknown";' in replies,
 'clarify_key_detected': 'return "clarify";' in replies and 's.contains("belirsiz")' in replies,
 'multiple_candidates_prompted': 'setTitle("Hangisini söylediniz?")' in hybrid and 'setItems(options.toArray(new String[0])' in hybrid,
 'multiple_candidates_repeat_option': 'setNegativeButton("Yeniden dinle"' in hybrid,
 'low_confidence_confirmation': 'setTitle("Doğru mu duydum?")' in hybrid and 'scores[0]>=0&&scores[0]<0.55f' in hybrid,
 'low_confidence_repeat_option': 'setNegativeButton("Tekrar dinle"' in hybrid,
 'unknown_routes_to_choice_when_multiple': 'CommandLanguage.conflict(options)||low||!known' in hybrid,
 'recognition_no_match_is_explained': 'case 7:return "Ses duyuldu ama sözcükler çözülemedi.' in recog,
 'unknown_voice_prompt_exists': '"unknown": "Bu isteği tam anlayamadım efendim. Biraz daha açık söyler misiniz?"' in phrases,
 'clarify_voice_prompt_exists': '"clarify": "İşleme devam edebilmem için hedefi biraz daha açık belirtmeniz gerekiyor efendim."' in phrases,
 'speech_choose_voice_prompt_exists': '"speech_choose": "Sözünüzü birden fazla şekilde duydum efendim.' in phrases,
}
assert all(checks.values()), [k for k,v in checks.items() if not v]

with zipfile.ZipFile(BASE) as z:
    assert z.testzip() is None
    dex=bytearray(z.read('classes.dex')); manifest=bytearray(z.read('AndroidManifest.xml'))
base_dex=bytes(dex)
E=entries(dex)
old_banner='JARVIS 1.6.4.14· SYSTEM ALARM'; new_banner='JARVIS 1.6.4.15· SYSTEM ALARM'
assert len(old_banner.encode('utf8'))==len(new_banner.encode('utf8'))
be=[x for x in E if x['text']==old_banner]; assert len(be)==1, [x['text'] for x in E if 'JARVIS 1.6.4' in x['text']][:20]
be=be[0]; dex[be['data']:be['end']]=new_banner.encode('utf8')
dex[12:32]=hashlib.sha1(dex[32:]).digest(); struct.pack_into('<I',dex,8,zlib.adler32(dex[12:])&0xffffffff)
new_dex=bytes(dex)
assert len(new_dex)==len(base_dex)==683080
assert gaps(new_dex)==[] and badsort(new_dex)==[]
assert hashlib.sha1(new_dex[32:]).digest()==new_dex[12:32]
assert (zlib.adler32(new_dex[12:])&0xffffffff)==u32(new_dex,8)
allowed=set(range(8,32))|set(range(be['data'],be['end']))
diffs=[i for i,(a,b) in enumerate(zip(base_dex,new_dex)) if a!=b]
unexpected=[i for i in diffs if i not in allowed]
assert not unexpected, unexpected[:20]

old_v='1.6.4.14-confirm-safe1'.encode('utf-16le'); new_v='1.6.4.15-smartfb-safe1'.encode('utf-16le')
assert len(old_v)==len(new_v) and manifest.count(old_v)==1
p=manifest.find(old_v); manifest[p:p+len(old_v)]=new_v

def u16m(o):return struct.unpack_from('<H',manifest,o)[0]
def u32m(o):return struct.unpack_from('<I',manifest,o)[0]
strings=[];pos=8;patched=False
while pos<len(manifest):
    typ=u16m(pos);hs=u16m(pos+2);sz=u32m(pos+4);assert sz>0
    if typ==1:
        count=u32m(pos+8);flags=u32m(pos+16);st=u32m(pos+20);base=pos+st;offs=[u32m(pos+hs+4*i) for i in range(count)];utf8=bool(flags&0x100)
        def l8(q):
            x=manifest[q];return ((((x&127)<<8)|manifest[q+1],2) if x&128 else (x,1))
        def l16(q):
            x=u16m(q);return ((((x&0x7fff)<<16)|u16m(q+2),4) if x&0x8000 else (x,2))
        strings=[]
        for so in offs:
            q=base+so
            if utf8:
                _,k=l8(q);q+=k;bl,k=l8(q);q+=k;strings.append(bytes(manifest[q:q+bl]).decode('utf8','replace'))
            else:
                ln,k=l16(q);q+=k;strings.append(bytes(manifest[q:q+ln*2]).decode('utf-16le','replace'))
    elif typ==0x0102 and strings and strings[u32m(pos+20)]=='manifest':
        ast=u16m(pos+24);asz=u16m(pos+26);ac=u16m(pos+28);a0=pos+16+ast
        for i in range(ac):
            a=a0+i*asz; nm=strings[u32m(a+4)]; tv=manifest[a+15]
            if nm=='versionCode' and tv==0x10:
                vc=u32m(a+16); assert vc==79,vc; struct.pack_into('<I',manifest,a+16,80); patched=True
    pos+=sz
assert patched
new_manifest=bytes(manifest); info=h.parse_axml_info(new_manifest)
assert info['package']=='com.hakan.jarvis' and info['versionCode']==80 and info['versionName']=='1.6.4.15-smartfb-safe1',info

unsigned=WORK/'unsigned.apk'
with zipfile.ZipFile(BASE) as zin, zipfile.ZipFile(unsigned,'w',allowZip64=False) as zout:
    for zi0 in zin.infolist():
        if zi0.filename.startswith('META-INF/'): continue
        data=zin.read(zi0.filename)
        if zi0.filename=='classes.dex': data=new_dex
        elif zi0.filename=='AndroidManifest.xml': data=new_manifest
        zi=zipfile.ZipInfo(zi0.filename,zi0.date_time); zi.compress_type=zi0.compress_type; zi.comment=zi0.comment; zi.extra=zi0.extra; zi.internal_attr=zi0.internal_attr; zi.external_attr=zi0.external_attr; zi.create_system=zi0.create_system; zi.flag_bits=zi0.flag_bits&~0x8
        zout.writestr(zi,data)

vals=h.load_signing(KEYDIR); v1=WORK/'v1.apk'; shutil.copy2(unsigned,v1)
r=subprocess.run(['jarsigner','-keystore',str(KEYDIR/'jarvis-release.jks'),'-storepass',vals['storepass'],'-keypass',vals['keypass'],'-sigalg','SHA256withRSA','-digestalg','SHA-256',str(v1),vals['alias']],capture_output=True,text=True); assert r.returncode==0,r.stdout+r.stderr
from cryptography.hazmat.primitives.serialization import pkcs12,Encoding,PublicFormat
p12=WORK/'r.p12'; r=subprocess.run(['keytool','-importkeystore','-noprompt','-srckeystore',str(KEYDIR/'jarvis-release.jks'),'-srcstoretype','JKS','-srcstorepass',vals['storepass'],'-srckeypass',vals['keypass'],'-srcalias',vals['alias'],'-destkeystore',str(p12),'-deststoretype','PKCS12','-deststorepass',vals['storepass'],'-destkeypass',vals['keypass'],'-destalias',vals['alias']],capture_output=True,text=True); assert r.returncode==0,r.stdout+r.stderr
key,cert,_=pkcs12.load_key_and_certificates(p12.read_bytes(),vals['storepass'].encode()); p12.unlink(missing_ok=True)
cert_der=cert.public_bytes(Encoding.DER); pub_der=key.public_key().public_bytes(Encoding.DER,PublicFormat.SubjectPublicKeyInfo)
OUT.write_bytes(h.add_v2(v1.read_bytes(),key,cert_der,pub_der))

with zipfile.ZipFile(OUT) as z, zipfile.ZipFile(BASE) as zb:
    assert z.testzip() is None
    dd=z.read('classes.dex'); assert len(dd)==683080 and gaps(dd)==[] and badsort(dd)==[]
    assert hashlib.sha1(dd[32:]).digest()==dd[12:32]
    assert (zlib.adler32(dd[12:])&0xffffffff)==u32(dd,8)
    names=set(z.namelist())|set(zb.namelist())
    pd=[n for n in names if (n not in z.namelist() or n not in zb.namelist() or z.read(n)!=zb.read(n)) and not n.startswith('META-INF/')]
    assert sorted(pd)==['AndroidManifest.xml','classes.dex'],pd
rv=subprocess.run(['jarsigner','-verify','-certs',str(OUT)],capture_output=True,text=True); assert rv.returncode==0 and 'jar verified' in (rv.stdout+rv.stderr).lower()
fp=h.verify_v2(OUT); assert fp==EXPECTED,(fp,EXPECTED)
ct=subprocess.run(['keytool','-printcert','-jarfile',str(OUT)],capture_output=True,text=True,check=True).stdout
m=re.search(r'SHA256:\s*([0-9A-F:]+)',ct,re.I); jarfp=m.group(1).upper(); assert jarfp==EXPECTED

rt=subprocess.run(['python','/mnt/data/j1641/tests/test_alarm_parser.py'],cwd='/mnt/data/j1641',capture_output=True,text=True); txt=rt.stdout+rt.stderr
assert rt.returncode==0 and 'TOTAL 1482 PASS' in txt and 'TOTAL 33 PASS' in txt and 'TOTAL 179 PASS' in txt,txt[-3000:]
sha=hashlib.sha256(OUT.read_bytes()).hexdigest()
QA.write_text('\n'.join([
'JARVIS 1.6.4.15 SMART FALLBACK SAFE','='*46,
'Base: JARVIS 1.6.4.14 CONFIRM-FIRST SAFE',
'Change scope: lock and verify existing safe fallback / clarification behavior; no runtime command/action code rewritten.',
'',
'SMART FALLBACK LOCK checks:',
*[f'- {k}: PASS' for k,v in checks.items()],
'',
'Behavior guaranteed by source contract:',
'- Multiple speech candidates or conflicting interpretations open a user-choice dialog.',
'- Low-confidence recognition asks “Doğru mu duydum?” before dispatch.',
'- User can choose “Tekrar dinle” / “Yeniden dinle”.',
'- Unknown legacy command has no after-action and cannot execute captured action.',
'- Ambiguous/clarify result has no after-action.',
'- No-match speech recognition produces an explanatory retry message.',
'- Unknown/clarify/speech-choice natural voice prompts are present in the offline voice bank.',
'',
'Previous features retained unchanged:',
'- wake-word tolerance','- alarm improvements','- microphone listening improvements','- natural torch commands','- time/date natural commands','- notes natural commands','- app command variants','- fuzzy app aliases','- neural voice tuning','- confirm-first action gating',
'',
'Package: com.hakan.jarvis','VersionCode: 80','VersionName: 1.6.4.15-smartfb-safe1','',
'QA:',
'- SMART FALLBACK lock: 12/12 PASS',
'- Runtime DEX code behavior vs 1.6.4.14: unchanged PASS',
'- DEX change limited to checksum/signature header + visible version banner PASS',
'- DEX length unchanged: 683080 bytes PASS','- New string_data items: 0 PASS','- DEX string_data gaps: 0 PASS','- DEX string-id order: PASS','- DEX SHA-1: PASS','- DEX Adler32: PASS',
'- Unexpected DEX byte changes: 0 PASS','- APK payload changes vs 1.6.4.14: AndroidManifest.xml + classes.dex only PASS','- ZIP CRC: PASS','- JAR/v1 signature: PASS','- APK v2 signature/content digest: PASS','- Production certificate: MATCH',
'- Alarm regression: 1482/1482 PASS','- Phone command regression: 33/33 PASS','- Understanding regression: 179/179 PASS','- Total legacy regression: 1694/1694 PASS',
'',f'APK SHA-256: {sha}',f'Certificate SHA-256: {jarfp}','',
'Physical-device launch remains the final runtime validation.'
]),encoding='utf8')
print('OUT',OUT,OUT.stat().st_size); print('SHA',sha); print('CERT',jarfp); print('LOCKS',sum(checks.values()),'/',len(checks)); print('REGRESSION 1694/1694 PASS'); print('DEX_DIFFS',len(diffs),'UNEXPECTED',len(unexpected))
