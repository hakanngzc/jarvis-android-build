from pathlib import Path
import zipfile, struct, hashlib, zlib, shutil, subprocess, re, importlib.util
GOOD=Path('/mnt/data/JARVIS_1.6.4.4_CRASHFIX.apk')
MANIFEST_SRC=Path('/mnt/data/JARVIS_1.6.4.5_CRASHFIX.apk')
OUT=Path('/mnt/data/JARVIS_1.6.4.5_SAFEDEX.apk')
QA=Path('/mnt/data/JARVIS_1.6.4.5_SAFEDEX_QA.txt')
WORK=Path('/mnt/data/j1645_safedex_work'); WORK.mkdir(exist_ok=True)
KEYDIR=Path('/mnt/data/j1641/private/JARVIS_BUILD_KEYS')
HELPER='/mnt/data/jarvis1641/src/build_v1641_speech_stability.py'
spec=importlib.util.spec_from_file_location('h',HELPER);h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);EXPECTED=h.EXPECTED_CERT

def u32(b,o): return struct.unpack_from('<I',b,o)[0]
def uleb(b,o):
    r=s=0;p=o
    while True:
        x=b[p];p+=1;r|=(x&127)<<s
        if not x&128:return r,p
        s+=7

def entries(b):
    n,so=u32(b,56),u32(b,60); out=[]
    for i in range(n):
        off=u32(b,so+4*i); ln,p=uleb(b,off); q=b.index(0,p)
        out.append({'idx':i,'off':off,'data':p,'end':q,'len':ln,'text':bytes(b[p:q]).decode('utf-8','replace')})
    return out

def badsort(b):
    e=entries(b); return [(i,e[i]['text'],e[i+1]['text']) for i in range(len(e)-1) if e[i]['text']>=e[i+1]['text']]

def gaps(b):
    e=entries(b); return [(i,e[i+1]['off']-(e[i]['end']+1)) for i in range(len(e)-1) if e[i+1]['off']!=(e[i]['end']+1)]

with zipfile.ZipFile(GOOD) as z:
    assert z.testzip() is None
    dex=bytearray(z.read('classes.dex'))
    good_manifest=z.read('AndroidManifest.xml')
with zipfile.ZipFile(MANIFEST_SRC) as z:
    manifest=bytearray(z.read('AndroidManifest.xml'))

base_dex=bytes(dex)
E=entries(dex)
old1='(?iu)^(?:hey )?(?:jarvis|carvis|cervis)[,:]? +'
old2='^(?:hey )?(?:jarvis|carvis|cervis)[,:]? +'
new1=r'(?iu)^(?:hey )?[jc][ae]rvi[sz][,:]?()()()\x20+'
new2=r'^(?:hey )?[jc][ae]rvi[sz][,:]?()()()\x20+'
assert E[3447]['text']==old1,(E[3447]['idx'],E[3447]['text'])
assert E[5973]['text']==old2,(E[5973]['idx'],E[5973]['text'])
assert len(old1.encode())==len(new1.encode())==46
assert len(old2.encode())==len(new2.encode())==41
assert E[3447]['len']==46 and E[5973]['len']==41
# exact-length in-place replacement only; no offsets, no padding, no section sizes touched
for idx,new in [(3447,new1),(5973,new2)]:
    e=E[idx]
    nb=new.encode('ascii')
    assert len(nb)==e['end']-e['data']
    dex[e['data']:e['end']]=nb
# visible banner only, exact UTF-8 byte length
E2=entries(dex)
banner_old='JARVIS 1.6.4.4 · SYSTEM ALARM'
banner_new='JARVIS 1.6.4.5 · SYSTEM ALARM'
be=[x for x in E2 if x['text']==banner_old]
assert len(be)==1
be=be[0]; ob=banner_old.encode(); nb=banner_new.encode(); assert len(ob)==len(nb)==be['end']-be['data']
dex[be['data']:be['end']]=nb
# recompute header integrity only
struct.pack_into('<I',dex,8,zlib.adler32(dex[12:]) & 0xffffffff) # temporary; overwritten after SHA
# DEX signature first, then checksum
sig=hashlib.sha1(dex[32:]).digest(); dex[12:32]=sig
struct.pack_into('<I',dex,8,zlib.adler32(dex[12:]) & 0xffffffff)
new_dex=bytes(dex)
assert len(new_dex)==len(base_dex)
assert hashlib.sha1(new_dex[32:]).digest()==new_dex[12:32]
assert (zlib.adler32(new_dex[12:]) & 0xffffffff)==u32(new_dex,8)
assert gaps(new_dex)==[], gaps(new_dex)[:10]
assert badsort(new_dex)==[], badsort(new_dex)[:10]
# ensure only header + exact 2 regex payloads + banner changed
allowed=set(range(8,32))
for idx in (3447,5973):
    e=E[idx]; allowed.update(range(e['data'],e['end']))
allowed.update(range(be['data'],be['end']))
diffs=[i for i,(a,b) in enumerate(zip(base_dex,new_dex)) if a!=b]
unexpected=[i for i in diffs if i not in allowed]
assert not unexpected,unexpected[:20]

# Manifest: source from 1.6.4.5, bump versionCode 68->69 and same-length versionName label
old_v='1.6.4.5-wakeword-fix01'.encode('utf-16le')
new_v='1.6.4.5-safedex-build1'.encode('utf-16le')
assert len(old_v)==len(new_v) and manifest.count(old_v)==1
p=manifest.find(old_v); manifest[p:p+len(old_v)]=new_v

def u16m(o):return struct.unpack_from('<H',manifest,o)[0]
def u32m(o):return struct.unpack_from('<I',manifest,o)[0]
strings=[];pos=8;patched=False
while pos<len(manifest):
    typ=u16m(pos); hs=u16m(pos+2); sz=u32m(pos+4); assert sz>0
    if typ==1:
        count=u32m(pos+8); flags=u32m(pos+16); st=u32m(pos+20); base=pos+st; offs=[u32m(pos+hs+4*i) for i in range(count)]; utf8=bool(flags&0x100)
        def l8(q):
            x=manifest[q]; return ((((x&127)<<8)|manifest[q+1],2) if x&128 else (x,1))
        def l16(q):
            x=u16m(q); return ((((x&0x7fff)<<16)|u16m(q+2),4) if x&0x8000 else (x,2))
        strings=[]
        for so in offs:
            q=base+so
            if utf8:
                _,k=l8(q);q+=k;bl,k=l8(q);q+=k;strings.append(bytes(manifest[q:q+bl]).decode('utf8','replace'))
            else:
                ln,k=l16(q);q+=k;strings.append(bytes(manifest[q:q+ln*2]).decode('utf-16le','replace'))
    elif typ==0x0102 and strings and strings[u32m(pos+20)]=='manifest':
        ast=u16m(pos+24); asz=u16m(pos+26); ac=u16m(pos+28); a0=pos+16+ast
        for i in range(ac):
            a=a0+i*asz; nm=strings[u32m(a+4)]; tv=manifest[a+15]
            if nm=='versionCode' and tv==0x10:
                vc=u32m(a+16); assert vc==68,vc; struct.pack_into('<I',manifest,a+16,69); patched=True
    pos+=sz
assert patched
new_manifest=bytes(manifest)
info=h.parse_axml_info(new_manifest)
assert info['package']=='com.hakan.jarvis' and info['versionCode']==69 and info['versionName']=='1.6.4.5-safedex-build1',info

# Repack from known-opening GOOD APK to preserve resources/payload, but use updated manifest + dex
unsigned=WORK/'unsigned.apk'
with zipfile.ZipFile(GOOD) as zin, zipfile.ZipFile(unsigned,'w',allowZip64=False) as zout:
    for zi0 in zin.infolist():
        if zi0.filename.startswith('META-INF/'): continue
        data=zin.read(zi0.filename)
        if zi0.filename=='classes.dex': data=new_dex
        elif zi0.filename=='AndroidManifest.xml': data=new_manifest
        zi=zipfile.ZipInfo(zi0.filename,zi0.date_time); zi.compress_type=zi0.compress_type; zi.comment=zi0.comment; zi.extra=zi0.extra; zi.internal_attr=zi0.internal_attr; zi.external_attr=zi0.external_attr; zi.create_system=zi0.create_system; zi.flag_bits=zi0.flag_bits&~0x8
        zout.writestr(zi,data)
# Sign v1 + v2 with production key
vals=h.load_signing(KEYDIR); v1=WORK/'v1.apk'; shutil.copy2(unsigned,v1)
r=subprocess.run(['jarsigner','-keystore',str(KEYDIR/'jarvis-release.jks'),'-storepass',vals['storepass'],'-keypass',vals['keypass'],'-sigalg','SHA256withRSA','-digestalg','SHA-256',str(v1),vals['alias']],capture_output=True,text=True); assert r.returncode==0,r.stdout+r.stderr
from cryptography.hazmat.primitives.serialization import pkcs12,Encoding,PublicFormat
p12=WORK/'r.p12'; r=subprocess.run(['keytool','-importkeystore','-noprompt','-srckeystore',str(KEYDIR/'jarvis-release.jks'),'-srcstoretype','JKS','-srcstorepass',vals['storepass'],'-srckeypass',vals['keypass'],'-srcalias',vals['alias'],'-destkeystore',str(p12),'-deststoretype','PKCS12','-deststorepass',vals['storepass'],'-destkeypass',vals['keypass'],'-destalias',vals['alias']],capture_output=True,text=True); assert r.returncode==0,r.stdout+r.stderr
key,cert,_=pkcs12.load_key_and_certificates(p12.read_bytes(),vals['storepass'].encode()); p12.unlink(missing_ok=True)
cert_der=cert.public_bytes(Encoding.DER); pub_der=key.public_key().public_bytes(Encoding.DER,PublicFormat.SubjectPublicKeyInfo)
OUT.write_bytes(h.add_v2(v1.read_bytes(),key,cert_der,pub_der))
# final verify
with zipfile.ZipFile(OUT) as z:
    assert z.testzip() is None
    dd=z.read('classes.dex')
    assert len(dd)==len(base_dex)
    assert gaps(dd)==[] and badsort(dd)==[]
    assert hashlib.sha1(dd[32:]).digest()==dd[12:32]
    assert (zlib.adler32(dd[12:])&0xffffffff)==u32(dd,8)
    assert z.read('AndroidManifest.xml')==new_manifest
rv=subprocess.run(['jarsigner','-verify','-certs',str(OUT)],capture_output=True,text=True); assert rv.returncode==0 and 'jar verified' in (rv.stdout+rv.stderr).lower()
fp=h.verify_v2(OUT); assert fp==EXPECTED,(fp,EXPECTED)
ct=subprocess.run(['keytool','-printcert','-jarfile',str(OUT)],capture_output=True,text=True,check=True).stdout
m=re.search(r'SHA256:\s*([0-9A-F:]+)',ct,re.I); jarfp=m.group(1).upper(); assert jarfp==EXPECTED
# wake-word Java behavior tests
js=WORK/'W.java'; js.write_text(r'''public class W{static int n=0;static void ok(boolean b,String m){if(!b)throw new AssertionError(m);n++;}public static void main(String[]x){String[] ps={"(?iu)^(?:hey )?[jc][ae]rvi[sz][,:]?()()()\\x20+","^(?:hey )?[jc][ae]rvi[sz][,:]?()()()\\x20+"};for(String w:new String[]{"jarvis","carvis","cervis","jervis","jarviz","carviz"})for(String p:ps){String a=w+" alarm kur";ok(!a.replaceFirst(p,"").equals(a),p+" "+w);String b="hey "+w+": feneri ac";ok(!b.replaceFirst(p,"").equals(b),p+" hey "+w);}for(String s:new String[]{"fenerbahce ac","carlos ac","jarmis alarm kur","servis ac"})for(String p:ps)ok(s.replaceFirst(p,"").equals(s),"false positive "+s);System.out.println("TOTAL "+n+" PASS");}}''',encoding='utf8')
subprocess.run(['javac',str(js)],cwd=WORK,check=True,capture_output=True,text=True)
rr=subprocess.run(['java','-cp',str(WORK),'W'],capture_output=True,text=True,check=True); assert 'TOTAL 32 PASS' in rr.stdout,rr.stdout
# alarm regression
t=subprocess.run(['python','/mnt/data/j1641/tests/test_alarm_parser.py'],cwd='/mnt/data/j1641',capture_output=True,text=True); txt=t.stdout+t.stderr; assert t.returncode==0 and 'TOTAL 1482 PASS' in txt and 'TOTAL 33 PASS' in txt and 'TOTAL 179 PASS' in txt,txt[-3000:]
sha=hashlib.sha256(OUT.read_bytes()).hexdigest()
QA.write_text('\n'.join([
'JARVIS 1.6.4.5 SAFEDEX','='*32,
'Base executable core: user-confirmed opening 1.6.4.4 CRASHFIX',
'Feature retained: jarvis/carvis/cervis/jervis/jarviz/carviz + optional hey + comma/colon',
'Implementation: exact-length regex replacement only; DEX file size and string offsets unchanged.',
'No DEX section growth. No new string_data item. No padding insertion. No code opcode changes.',
'',
'Package: com.hakan.jarvis','VersionCode: 69','VersionName: 1.6.4.5-safedex-build1',
'',
'QA:',
'- DEX total length unchanged: PASS',
'- DEX string_data gaps: 0 PASS',
'- DEX string-id order: PASS',
'- DEX SHA-1: PASS','- DEX Adler32: PASS','- ZIP CRC: PASS',
'- JAR/v1 signature: PASS','- APK v2 signature/content digest: PASS','- Production certificate: MATCH',
'- Wake-word behavior: 32/32 PASS','- Alarm regression: 1694/1694 PASS',
'- Exact-length wake regex slot 1: 46 -> 46 bytes PASS','- Exact-length wake regex slot 2: 41 -> 41 bytes PASS',
'',f'APK SHA-256: {sha}',f'Certificate SHA-256: {jarfp}',
'', 'Note: physical vivo launch remains the final runtime validation.'
]),encoding='utf8')
print('OUT',OUT,OUT.stat().st_size)
print('SHA',sha)
print('CERT',jarfp)
print('DEX_LEN',len(new_dex))
print('DIFFS',len(diffs),'UNEXPECTED',len(unexpected))
print(rr.stdout.strip())
print('ALARM 1694/1694 PASS')
