# 1.6.4.11 NOTES SAFE method

This release starts from the 1.6.4.10 APK payload and changes only the notes-list routing regex plus release metadata.

Old regex (36 bytes):
`notlarim(?:i goster)?|notlari goster`

New regex (36 bytes):
`notlarim(i? [go].*)?|notlari [go].*$`

The new form keeps the string in the same DEX string-id ordering interval while accepting natural read-only notes phrases such as `notlarimi oku`, `notlari oku`, `notlarim oku`, `notlarim goster`, and all previously-supported display forms. The `[go].*` branch is intentionally confined to the notes display route, which is read-only.

DEX size stays 683080 bytes. No string offsets, padding, method instructions, alarm logic, microphone logic, wake-word logic, or voice logic are changed.
