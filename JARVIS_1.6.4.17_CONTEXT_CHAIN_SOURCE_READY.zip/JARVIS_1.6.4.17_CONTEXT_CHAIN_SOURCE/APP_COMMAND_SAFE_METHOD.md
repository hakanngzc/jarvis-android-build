# JARVIS 1.6.4.12 APP COMMAND SAFE method

This release starts from the 1.6.4.11 NOTES SAFE APK and expands only app-open language handling plus release metadata.

The APK keeps the same DEX size and uses two equal-length string substitutions:

1. App route regex, 56 bytes -> 56 bytes
   - before: `^(?:uygulama )?(.+?) +(uygulamasini )?(bi )?(ac|baslat)$`
   - after:  `^(?:uygulama )?(.+?) +(ac|baslat|gir(sene)?|calistir)()$`

2. App target cleanup regex, 15 bytes -> 15 bytes
   - before: ` +uygulamasini$`
   - after:  ` +uyg.*$| +bi\Z`

Together these retain the existing `ac`, `baslat`, `bi ac`, and `uygulamasini ac` forms while adding `gir`, `girsene`, and `calistir`. The cleanup runs only on the already-selected app target.

No DEX string_data item is inserted. DEX size remains 683080 bytes. No method instruction/opcode is added or removed. Alarm, microphone, wake-word, notes, time/date and voice logic are unchanged.
