package com.hakan.jarvis;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.*;
import android.speech.*;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import java.util.*;
import java.text.SimpleDateFormat;
import java.util.concurrent.*;
import org.json.*;

/** Hybrid layer over the exact 1.5.7 command engine. */
public final class HybridActivity extends MainActivity {
    private SharedPreferences prefs;
    private VoiceController voice;
    private PhoneActions phone;
    private TextView voiceStatus,recognitionStatus,heard;
    private ProgressBar micLevel;
    private boolean waitingFinal,spokenCommand,pendingSpoken;
    private String pendingAlarm="",pendingQuestion="";
    private PhoneCommand pendingConfirmation;
    private long pendingAt;
    private AlertDialog confirmationDialog,recognitionDialog;
    private boolean capturingAction;
    private Runnable deferredAction;
    private String chainedNext="";
    private boolean internalChainDispatch;
    private int recognitionEpoch;
    private boolean chainTerminalKey(String key){return key!=null&&key.matches("time|date|calculation|notes|online|offline|help|weather|currency|knowledge|cached|stale|torch_on|torch_off");}
    private boolean chainFailureKey(String key){return key!=null&&key.matches("error|unknown|clarify|calculation_error|network_error|offline_missing|timeout|recognition_error|recognition_unavailable|phone_clarify|torch_error|torch_missing|torch_denied");}
    private void continueChain(){final String next=chainedNext;chainedNext="";if(next.length()==0)return;handler.post(new Runnable(){public void run(){if(dead)return;internalChainDispatch=true;try{dispatch(next);}finally{internalChainDispatch=false;}}});}
    private void say(String text,String key,Runnable after){
        if(voice==null)return;Runnable done=after;
        if(chainedNext.length()>0&&chainTerminalKey(key)){final Runnable action=after;done=new Runnable(){public void run(){if(action!=null)action.run();continueChain();}};}
        else if(chainedNext.length()>0&&chainFailureKey(key))chainedNext="";
        voice.speak(text,key,isOnline()&&prefs.getBoolean("cloud_voice",true),done);
    }
    private boolean chainFirstSafe(String raw){
        PhoneCommand pc=PhoneCommand.parse(raw);if(pc!=null)return pc.error==null&&pc.kind.equals("torch");
        HybridEngine.Request r=HybridEngine.route(CommandLanguage.canonical(raw),prefs.getString("city","Kahramanmaraş"));
        return r!=null&&r.kind.matches("time|date|calc|notes|status|help|weather|currency|wiki");
    }
    private String textAt(int id){View v=findViewById(id);return v instanceof TextView?((TextView)v).getText().toString():"";}
    @Override public void startActivityForResult(final Intent intent,final int code){
        if(capturingAction){deferredAction=new Runnable(){public void run(){HybridActivity.super.startActivityForResult(intent,code);}};return;}
        super.startActivityForResult(intent,code);
    }
    @Override public void startActivity(final Intent intent){
        if(capturingAction){deferredAction=new Runnable(){public void run(){HybridActivity.super.startActivity(intent);}};return;}
        super.startActivity(intent);
    }
    private HybridEngine engine;
    private HybridEngine.HttpsTransport http;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private Future<?> pending;
    private int generation;
    private boolean dead, registered;
    private TextView answer, meta;
    private Button retry,cancel;
    private HybridEngine.Request last;
    private SpeechRecognizer recognizer;
    private boolean listening;
    private final BroadcastReceiver networkReceiver=new BroadcastReceiver(){public void onReceive(Context c,Intent i){updateHybridStatus();}};
    private final Runnable speechTimeout=new Runnable(){public void run(){recognitionFailure(6);}};

    @Override protected void onCreate(Bundle state) {
        prefs=getSharedPreferences("jarvis_hybrid",MODE_PRIVATE);
        AlarmStore.restore(this);
        super.onCreate(state);
        http=new HybridEngine.HttpsTransport();engine=new HybridEngine(getFilesDir(),http);
        ViewGroup content=(ViewGroup)findViewById(android.R.id.content);
        LinearLayout root=(LinearLayout)content.getChildAt(0);content.removeView(root);
        root.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.addView(root);setContentView(scroll);
        for(int i=0;i<root.getChildCount();i++){
            View v=root.getChildAt(i);
            if(v instanceof TextView){TextView t=(TextView)v;String s=t.getText().toString();if(s.contains("v1.5.7"))t.setText("JARVIS 1.6.4.17 · CONTEXT CHAIN SAFE");}
        }
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
        Button write=button("YAZ",new View.OnClickListener(){public void onClick(View v){showInput();}});
        Button settings=button("HİBRİT AYARLAR",new View.OnClickListener(){public void onClick(View v){showSettings();}});
        row.addView(write,new LinearLayout.LayoutParams(0,-2,1));row.addView(settings,new LinearLayout.LayoutParams(0,-2,1));root.addView(row);
        voiceStatus=new TextView(this);voiceStatus.setTextSize(14);voiceStatus.setTextColor(0xff99bacb);voiceStatus.setText("Ses: HAZIR · Türkçe doğal erkek sesi");root.addView(voiceStatus);
        recognitionStatus=new TextView(this);recognitionStatus.setTextColor(0xff00ddeb);recognitionStatus.setText("DİNLE'ye dokunun; DİNLİYOR yazınca konuşun.");root.addView(recognitionStatus);
        micLevel=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);micLevel.setMax(100);root.addView(micLevel,new LinearLayout.LayoutParams(-1,12));
        heard=new TextView(this);heard.setTextColor(0xffeaf4ff);heard.setText("Duyduğum: —");root.addView(heard);
        root.addView(button("ALARMLARIM",new View.OnClickListener(){public void onClick(View v){showAlarms();}}));
        root.addView(button("ALTERNATİF DİNLEME",new View.OnClickListener(){public void onClick(View v){alternativeListening();}}));
        LinearLayout voiceRow=new LinearLayout(this);
        voiceRow.addView(button("SESİ TEKRARLA",new View.OnClickListener(){public void onClick(View v){if(voice!=null)voice.repeat(isOnline()&&prefs.getBoolean("cloud_voice",true));}}),new LinearLayout.LayoutParams(0,-2,1));
        voiceRow.addView(button("SESİ DURDUR",new View.OnClickListener(){public void onClick(View v){if(voice!=null)voice.stop();if(phone!=null)phone.cancel();clearAlarmConversation();stopRecognition();deferredAction=null;chainedNext="";voiceStatus.setText("Ses: DURDU");}}),new LinearLayout.LayoutParams(0,-2,1));root.addView(voiceRow);
        answer=new TextView(this);answer.setTextColor(0xffeaf4ff);answer.setTextSize(19);answer.setPadding(0,24,0,12);answer.setTextIsSelectable(true);root.addView(answer,new LinearLayout.LayoutParams(-1,-2));
        meta=new TextView(this);meta.setTextColor(0xff99bacb);meta.setTextSize(13);meta.setTextIsSelectable(true);root.addView(meta,new LinearLayout.LayoutParams(-1,-2));
        retry=button("YENİDEN DENE",new View.OnClickListener(){public void onClick(View v){if(last!=null)request(last);}});retry.setVisibility(View.GONE);root.addView(retry);
        cancel=button("İPTAL",new View.OnClickListener(){public void onClick(View v){cancelWork();if(voice!=null)voice.beginTurn();local("İptal edildi","Yerel komutları kullanmaya devam edebilirsiniz.");}});cancel.setVisibility(View.GONE);root.addView(cancel);
        local("Hibrit sistem hazır", "Örnekler: YouTube’u aç · feneri aç/kapat · sabah yediye alarm kur · Kahramanmaraş hava durumu · dolar kuru · bilgi Ankara · saat kaç · hesapla 12*(3+4) · not al …\n\nİnternet yokken yerel komutlar ve daha önce alınmış veriler kullanılabilir.");
        if(state!=null){answer.setText(state.getString("hybrid_answer",answer.getText().toString()));meta.setText(state.getString("hybrid_meta",""));String k=state.getString("last_kind");if(k!=null){last=new HybridEngine.Request(k,state.getString("last_query",""));retry.setVisibility(View.VISIBLE);}}
        updateHybridStatus();
        setVolumeControlStream(android.media.AudioManager.STREAM_MUSIC);
        voice=new VoiceController(this,new VoiceController.Listener(){public void state(String state,String detail){if(!dead)voiceStatus.setText("Ses: "+state+(detail.length()>0?" · "+detail:""));}});
        phone=new PhoneActions(this,new PhoneActions.Host(){public void say(String text,String key,Runnable after){HybridActivity.this.say(text,key,after);}public void show(String title,String detail){setText(2002,title);setText(2003,detail.split("\\n")[0]);answer.setText(title+"\n\n"+detail);meta.setText("Telefon komutu · 1.6.2");}});
    }
    private Button button(String title,View.OnClickListener action){Button b=new Button(this);b.setText(title);b.setOnClickListener(action);return b;}
    @Override protected boolean isOnline(){
        if(prefs!=null&&prefs.getBoolean("force_offline",false))return false;
        try {ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);Network n=cm.getActiveNetwork();NetworkCapabilities c=cm.getNetworkCapabilities(n);return c!=null&&c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)&&c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);}catch(Exception e){return false;}
    }
    @Override protected void updateHybridStatus(){View v=findViewById(2006);if(v instanceof TextView)((TextView)v).setText(isOnline()?"ONLINE · gerçek veri + yerel komutlar":"OFFLINE · yerel komutlar + kayıtlı veriler");}
    @Override protected void onResume(){super.onResume();updateHybridStatus();if(!registered){try{registerReceiver(networkReceiver,new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));registered=true;}catch(Exception ignored){}}}
    @Override protected void onPause(){if(phone!=null)phone.pause();if(registered){try{unregisterReceiver(networkReceiver);}catch(Exception ignored){}registered=false;}stopRecognition();if(voice!=null)voice.stop();deferredAction=null;chainedNext="";super.onPause();}
    @Override protected void onSaveInstanceState(Bundle b){super.onSaveInstanceState(b);if(answer!=null){b.putString("hybrid_answer",answer.getText().toString());b.putString("hybrid_meta",meta.getText().toString());}if(last!=null){b.putString("last_kind",last.kind);b.putString("last_query",last.query);}}
    @Override protected void onDestroy(){dead=true;clearAlarmConversation();if(recognitionDialog!=null)recognitionDialog.dismiss();if(phone!=null)phone.destroy();cancelWork();stopRecognition();if(voice!=null)voice.destroy();worker.shutdownNow();handler.removeCallbacksAndMessages(null);super.onDestroy();}
    private void cancelWork(){generation++;if(pending!=null){pending.cancel(true);pending=null;}if(http!=null)http.cancel();if(cancel!=null)cancel.setVisibility(View.GONE);}
    private void local(String title,String text){if(answer==null)return;answer.setText(title+"\n\n"+text);meta.setText("Yerel işlem · internet gerekmez");meta.setOnClickListener(null);if(retry!=null)retry.setVisibility(View.GONE);say(VoiceReplies.localText(title,text),VoiceReplies.localKey(title,text),null);}
    private void setText(int id,String text){View v=findViewById(id);if(v instanceof TextView)((TextView)v).setText(text);}
    private void showInput(){
        stopRecognition();
        if(voice!=null)voice.beginTurn();if(phone!=null)phone.cancel();deferredAction=null;
        final EditText input=new EditText(this);input.setTextColor(0xff111111);input.setHint("Komut veya soru yazın");input.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);input.setMaxLines(4);
        final AlertDialog dialog=new AlertDialog.Builder(this).setTitle("JARVIS'e yaz").setView(input).setPositiveButton("Gönder",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){dispatch(input.getText().toString());}}).setNegativeButton("Vazgeç",null).create();
        dialog.getWindow();dialog.show();input.requestFocus();dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
    }
    private void showSettings(){
        LinearLayout layout=new LinearLayout(this);layout.setOrientation(1);layout.setPadding(32,16,32,8);
        final EditText city=new EditText(this);city.setSingleLine(true);city.setHint("Varsayılan şehir");city.setText(prefs.getString("city","Kahramanmaraş"));layout.addView(city);
        final CheckBox offline=new CheckBox(this);offline.setText("Yalnızca çevrimdışı kullan");offline.setChecked(prefs.getBoolean("force_offline",false));layout.addView(offline);
        TextView info=new TextView(this);info.setText("Çevrimdışı ses tanıma, telefonda Türkçe model desteği gerektirir. Yazılı komutlar her zaman kullanılabilir.\n\nDoğal Türkçe erkek sesi aktiftir. İnternette ayrıntılı yanıtlar seslendirilir; çevrimdışıyken aynı sesin gömülü komut yanıtları kullanılır. Android sistem TTS kullanılmaz.");layout.addView(info);
        final CheckBox cloud=new CheckBox(this);cloud.setText("Çevrimiçi ayrıntılı konuşma");cloud.setChecked(prefs.getBoolean("cloud_voice",true));layout.addView(cloud);
        TextView privacy=new TextView(this);privacy.setText("Açıkken seslendirilecek yanıt metni Microsoft'un çevrimiçi ses servisine gönderilir. Kapalıyken gömülü kayıtlar ve önceden alınmış sesler kullanılır.");layout.addView(privacy);
        layout.addView(button("KONUŞMA TANIMA AYARLARI",new View.OnClickListener(){public void onClick(View v){try{startActivity(new Intent(android.provider.Settings.ACTION_VOICE_INPUT_SETTINGS));}catch(Exception e){try{startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));}catch(Exception ignored){}}}}));
        layout.addView(button("SESİ DENE",new View.OnClickListener(){public void onClick(View v){voice.beginTurn();say("","voice_test",null);}}));
        layout.addView(button("KAYITLI İNTERNET VERİLERİNİ TEMİZLE",new View.OnClickListener(){public void onClick(View v){cancelWork();worker.submit(new Runnable(){public void run(){engine.clearCache();handler.post(new Runnable(){public void run(){if(!dead)local("Önbellek temizlendi","Notlarınız korunuyor.");}});}});}}));
        ScrollView settingsScroll=new ScrollView(this);settingsScroll.addView(layout);
        new AlertDialog.Builder(this).setTitle("Hibrit ayarlar").setView(settingsScroll).setPositiveButton("Kaydet",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){String c=city.getText().toString().trim();prefs.edit().putString("city",c.length()==0?"Kahramanmaraş":c).putBoolean("force_offline",offline.isChecked()).putBoolean("cloud_voice",cloud.isChecked()).apply();cancelWork();stopRecognition();voice.beginTurn();updateHybridStatus();say("","settings_saved",null);}}).setNegativeButton("Vazgeç",null).show();
    }
    private void clearLegacyLabels(ViewGroup group){for(int i=0;i<group.getChildCount();i++){View v=group.getChildAt(i);if(v instanceof ViewGroup)clearLegacyLabels((ViewGroup)v);else if(v instanceof TextView&&((TextView)v).getText().toString().startsWith("Bağlam hafızası:"))((TextView)v).setText("");}}
    private void showAlarms(){
        stopRecognition();voice.beginTurn();phone.cancel();clearAlarmConversation();
        final java.util.List<JSONObject> list=AlarmStore.list(this);if(list.isEmpty()){answer.setText("Kayıtlı alarm yok.");say("","alarms_empty",null);return;}
        String[] labels=new String[list.size()];for(int i=0;i<list.size();i++){JSONObject a=list.get(i);String st=a.optString("state");String status=st.equals("scheduled")?(AlarmStore.permitted(this)?"KURULU":"İZİN KAPALI"):st.equals("finished")?"ÇALDI / DURDU":st.equals("ringing")?"ÇALIYOR":st.equals("missed")?"KAÇIRILDI":"KONTROL GEREKİYOR";labels[i]=a.optString("label")+" · "+status;}
        new AlertDialog.Builder(this).setTitle("Alarmlarım · silmek için seçin").setItems(labels,new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){final JSONObject a=list.get(w);new AlertDialog.Builder(HybridActivity.this).setTitle("Alarm silinsin mi?").setMessage(a.optString("label")).setPositiveButton("SİL",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){voice.beginTurn();say("","alarm_delete",new Runnable(){public void run(){AlarmStore.cancel(HybridActivity.this,a.optInt("id"));answer.setText("Alarm silindi.");}});}}).setNegativeButton("Vazgeç",null).show();}}).setNegativeButton("Kapat",null).show();say("","alarms_list",null);
    }
    private void clearAlarmConversation(){pendingAlarm="";pendingQuestion="";pendingConfirmation=null;pendingSpoken=false;if(confirmationDialog!=null){confirmationDialog.dismiss();confirmationDialog=null;}}
    private void confirmAlarm(){
        PhoneCommand c=pendingConfirmation;if(c==null)return;if(System.currentTimeMillis()-pendingAt>90000){clearAlarmConversation();say("","cancel",null);return;}clearAlarmConversation();voice.beginTurn();phone.handle(c);
    }
    private void showAlarmConfirmation(final PhoneCommand c){
        pendingConfirmation=c;pendingAt=System.currentTimeMillis();answer.setText("Alarm: "+c.plan.label()+"\n\nDoğruysa ONAYLA'ya dokunun veya DİNLE ile ‘evet’ deyin. Henüz kaydedilmedi.");meta.setText("Saat onayı bekleniyor");
        say("Alarmı "+c.plan.label()+" olarak anladım efendim. Onaylıyor musunuz?","alarm_confirm",null);
        confirmationDialog=new AlertDialog.Builder(this).setTitle("Alarm: "+c.plan.label()).setMessage("Bu tarih ve saat doğru mu? Onay ve sesli yanıtın ardından JARVIS kaydedecek.").setPositiveButton("ONAYLA",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){confirmAlarm();}}).setNegativeButton("DÜZELT",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){clearAlarmConversation();pendingAlarm=c.plan.context+" alarm kur";pendingQuestion="time";pendingSpoken=true;pendingAt=System.currentTimeMillis();voice.beginTurn();answer.setText("Alarmı kaça ayarlayayım?");say("","alarm_ask_time",null);}}).setNeutralButton("SESLİ YANIT",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){confirmationDialog=null;beginListening();}}).create();confirmationDialog.setOnCancelListener(new DialogInterface.OnCancelListener(){public void onCancel(DialogInterface d){clearAlarmConversation();voice.beginTurn();say("","cancel",null);}});confirmationDialog.show();
    }
    private boolean phoneConversation(String raw){
        String n=CommandLanguage.clean(raw);if(System.currentTimeMillis()-pendingAt>90000)clearAlarmConversation();
        if(n.matches("(?:iptal|vazgec|hayir|iptal et)")){clearAlarmConversation();say("","cancel",null);answer.setText("İşlem iptal edildi.");return true;}
        if(pendingConfirmation!=null&&n.matches("(?:evet|onayla|onayliyorum|tamam|dogru)")){confirmAlarm();return true;}
        boolean confirm=spokenCommand||pendingSpoken;
        if(pendingConfirmation!=null)clearAlarmConversation();
        PhoneCommand pc=PhoneCommand.parse(raw);
        if(pc==null&&pendingAlarm.length()>0){
            if(pendingQuestion.equals("date")&&n.matches("yarin|bugun|pazartesi|sali|carsamba|persembe|cuma|cumartesi|pazar"))raw=pendingAlarm.replaceAll("\\b(yarin|bugun|pazartesi|sali|carsamba|persembe|cuma|cumartesi|pazar)\\b","")+" "+n;
            else if(pendingQuestion.equals("period")&&n.matches("sabah|aksam|gece|oglen"))raw=pendingAlarm+" "+n;
            else {AlarmTime t=AlarmTime.parse(n);if(t.error==null||t.question.equals("period"))raw=AlarmPlan.context(pendingAlarm)+" "+n+" alarm kur";else {clearAlarmConversation();return false;}}
            pc=PhoneCommand.parse(raw);
        }
        if(pc==null){clearAlarmConversation();return false;}
        if(pc.kind.equals("alarm")){
            AlarmPlan t=pc.plan;
            setText(2002,"Niyet: ALARM");setText(2003,t.error==null?t.label():t.error);
            if(t.error!=null&&t.question.length()>0){pendingAlarm=CommandLanguage.clean(raw);pendingQuestion=t.question;pendingSpoken=confirm;pendingAt=System.currentTimeMillis();answer.setText(t.error);meta.setText("Yanıtı DİNLE veya YAZ ile verebilirsiniz. İptal demek işlemi sonlandırır.");say("",t.question.equals("period")?"alarm_ask_period":t.question.equals("date")?"alarm_ask_day":"alarm_ask_time",null);return true;}
            clearAlarmConversation();if(pc.error==null){showAlarmConfirmation(pc);return true;}
        }else clearAlarmConversation();
        phone.handle(pc);return true;
    }
    private void dispatch(String raw){
        stopRecognition();
        if(!internalChainDispatch){
            chainedNext="";CommandChain.Result chain=CommandChain.parse(raw);
            if(chain.error!=null){local("Zincir komutu",chain.error);return;}
            if(chain.chained()){String first=chain.commands.get(0);if(!chainFirstSafe(first)){local("Zincir komutu","İlk aşamada zincirin ilk komutu saat, tarih, hesap, notları göster, bağlantı/bilgi sorgusu veya fener komutu olmalı. Uygulama açma komutu zincirin ikinci adımı olabilir.");return;}chainedNext=chain.commands.get(1);raw=first;}
        }
        if(voice!=null)voice.beginTurn();if(phone!=null)phone.cancel();deferredAction=null;
        raw=raw.trim();if(raw.length()==0)return;if(raw.length()>500){chainedNext="";local("Komut çok uzun","Lütfen 500 karakterden kısa yazın.");return;}
        cancelWork();last=null;updateHybridStatus();setText(2001,raw);setText(2002,"");setText(2003,"");clearLegacyLabels((ViewGroup)findViewById(android.R.id.content));
        if(CommandLanguage.clean(raw).matches("alarmlarim|alarmlari goster|alarmlarimi goster")){showAlarms();return;}
        if(phoneConversation(raw))return;
        raw=CommandLanguage.canonical(raw);
        String wake=HybridEngine.normalize(raw);
        if(CommandLanguage.isWake(raw)){answer.setText("Buradayım efendim. Sizi dinliyorum.");meta.setText("JARVIS · doğal Türkçe ses");setText(2002,"");setText(2003,"");say("","wake",null);return;}
        HybridEngine.Request r=HybridEngine.route(raw,prefs.getString("city","Kahramanmaraş"));
        if(r==null){
            answer.setText("");meta.setText("");ArrayList<String> results=new ArrayList<String>();results.add(raw);Intent data=new Intent();data.putStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS,results);
            try{capturingAction=true;super.onActivityResult(101,RESULT_OK,data);}catch(RuntimeException e){deferredAction=null;local("Komut tamamlanamadı","Bu işlemi telefon desteklemiyor veya gerekli izin kapalı. İzinleri kontrol edip tekrar deneyin.");return;}finally{capturingAction=false;}
            final Runnable action=deferredAction;deferredAction=null;
            String key=VoiceReplies.legacyKey(textAt(2002),textAt(2003),action!=null);
            if(key.equals("not_executed")){answer.setText("Komut tanındı; otomatik işlem uygulanmadı. Çözümlenen hedef yukarıda.");}
            say("",key,(key.equals("clarify")||key.equals("unknown"))?null:action);return;
        }
        setText(2002,"Hibrit · "+(r.kind.equals("weather")?"Hava durumu":r.kind.equals("currency")?"Kur":r.kind.equals("wiki")?"Bilgi":"Yerel komut"));setText(2003,"");
        if(r.kind.equals("weather")||r.kind.equals("currency")||r.kind.equals("wiki")){request(r);return;}
        if(r.kind.equals("time")){local("Saat",new SimpleDateFormat("HH:mm",new Locale("tr","TR")).format(new Date()));return;}
        if(r.kind.equals("date")){local("Bugün",new SimpleDateFormat("d MMMM yyyy, EEEE",new Locale("tr","TR")).format(new Date()));return;}
        if(r.kind.equals("calc")){try{local("Hesaplama",r.query+" = "+HybridEngine.format(HybridEngine.calculate(r.query)));}catch(Exception e){local("Hesaplanamadı","Sayılar, + − * / ve parantez kullanın. Sıfıra bölme yapılamaz.");}return;}
        if(r.kind.equals("note")){try{JSONArray notes=new JSONArray(prefs.getString("notes","[]"));if(notes.length()>=100){local("Not alanı dolu","En fazla 100 not saklanabilir.");return;}notes.put(new JSONObject().put("text",r.query).put("time",System.currentTimeMillis()));prefs.edit().putString("notes",notes.toString()).apply();local("Not kaydedildi",r.query);}catch(Exception e){local("Not kaydedilemedi","Lütfen yeniden deneyin.");}return;}
        if(r.kind.equals("notes")){try{JSONArray notes=new JSONArray(prefs.getString("notes","[]"));StringBuilder b=new StringBuilder();for(int i=notes.length()-1;i>=0;i--){JSONObject n=notes.getJSONObject(i);b.append(new SimpleDateFormat("dd.MM HH:mm",Locale.getDefault()).format(new Date(n.getLong("time")))).append(" · ").append(n.getString("text")).append("\n\n");}local("Notlarım",b.length()==0?"Henüz not yok. “Not al …” yazabilirsiniz.":b.toString());}catch(Exception e){local("Notlar okunamadı","Kayıtlar silinmedi.");}return;}
        if(r.kind.equals("unsupportedWeather")){local("Güncel hava verisi","Bu sürüm mevcut hava koşullarını getirir. “Kahramanmaraş hava durumu” yazabilirsiniz.");return;}
        if(r.kind.equals("status")){local("Bağlantı",isOnline()?"İnternet bağlantısı doğrulandı. Servis yanıtları istek sırasında ayrıca kontrol edilir.":"Çevrimdışı mod. Yerel komutlar ve kayıtlı internet verileri kullanılabilir.");return;}
        local("Hibrit yardım","İNTERNETTEN: “Ankara hava durumu”, “dolar kuru”, “bilgi Ankara”, “Atatürk kimdir”.\n\nÇEVRİMDIŞI: “saat kaç”, “bugün hangi gün”, “hesapla 12*(3+4)”, “not al …”, “notlarım”. Mevcut telefon komutları da korunur. İnternet gerektiren başka uygulamalar çevrimdışıyken veri alamaz.\n\nEski internet sonuçları kayıt zamanı ve güncellik uyarısıyla gösterilir. İnternette bilgi yanıtları doğal sesle okunur. Çevrimdışıyken aynı sesin komuta uygun gömülü yanıtları kullanılır.");
    }
    private void request(final HybridEngine.Request r){
        if(voice!=null)voice.beginTurn();
        cancelWork();last=r;say("","checking",null);final int id=generation;final boolean online=isOnline();
        answer.setText(online?"Veri alınıyor…":"Kayıtlı veri aranıyor…");meta.setText("Yerel komutlar kullanılabilir. Yeni komut önceki isteği iptal eder.");meta.setOnClickListener(null);retry.setVisibility(View.GONE);cancel.setVisibility(View.VISIBLE);
        final Runnable timeout=new Runnable(){public void run(){if(dead||generation!=id)return;cancelWork();answer.setText("İstek zaman aşımına uğradı. Yeniden deneyebilirsiniz.");say("","timeout",null);meta.setText("Yerel komutlar kullanılabilir.");retry.setVisibility(View.VISIBLE);}};
        handler.postDelayed(timeout,18000);
        pending=worker.submit(new Runnable(){public void run(){
            try {final HybridEngine.Answer a=engine.fetch(r,online,System.currentTimeMillis());handler.post(new Runnable(){public void run(){handler.removeCallbacks(timeout);if(dead||generation!=id)return;cancel.setVisibility(View.GONE);answer.setText(a.title+"\n\n"+a.text);say(VoiceReplies.answerText(a),VoiceReplies.answerKey(r,a),null);String date=new SimpleDateFormat("dd.MM.yyyy HH:mm",new Locale("tr","TR")).format(new Date(a.fetchedAt));meta.setText((a.cached?"KAYITLI VERİ · "+(a.stale?"GÜNCELLİĞİNİ YİTİRMİŞ OLABİLİR":"canlı olarak doğrulanmadı"):"İNTERNETTEN ALINDI")+"\nAlınma: "+date+"\nKaynak: "+a.source+"\nKaynağı açmak için dokunun.");meta.setOnClickListener(new View.OnClickListener(){public void onClick(View v){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(a.url)));}catch(Exception ignored){}}});retry.setVisibility(View.VISIBLE);}});}
            catch(final Exception e){handler.post(new Runnable(){public void run(){handler.removeCallbacks(timeout);if(dead||generation!=id)return;cancel.setVisibility(View.GONE);answer.setText(e instanceof HybridEngine.Unavailable?e.getMessage():"Veri alınamadı. Lütfen yeniden deneyin.");meta.setText("Bilgi uydurulmadı · yerel komutlar aktif");say("",isOnline()?"network_error":"offline_missing",null);retry.setVisibility(View.VISIBLE);}});}
        }});
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        if(requestCode==812){if(resultCode==RESULT_OK&&data!=null)acceptSpeech(data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS),null);else{voice.beginTurn();say("","cancel",null);}return;}
        if(requestCode==101&&resultCode==RESULT_OK&&data!=null){acceptSpeech(data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS),null);return;}
        super.onActivityResult(requestCode,resultCode,data);
    }
    private void acceptSpeech(ArrayList<String> texts,float[] scores){
        if(texts==null||texts.isEmpty()){recognitionFailure(7);return;}
        final ArrayList<String> options=new ArrayList<String>();for(String text:texts)if(text!=null&&text.trim().length()>0&&!options.contains(text.trim())&&options.size()<5)options.add(text.trim());
        if(options.isEmpty()){recognitionFailure(7);return;}
        String top=options.get(0);heard.setText("Duyduğum: "+top);String n=CommandLanguage.clean(top);
        PhoneCommand pc=PhoneCommand.parse(top);boolean known=pc!=null||HybridEngine.route(CommandLanguage.canonical(top),prefs.getString("city","Kahramanmaraş"))!=null||CommandLanguage.isWake(top)||pendingAlarm.length()>0||pendingConfirmation!=null;
        boolean low=scores!=null&&scores.length>0&&scores[0]>=0&&scores[0]<0.55f;
        if(options.size()>1&&(CommandLanguage.conflict(options)||low||!known||(pc!=null&&pc.error!=null))){
            say("","speech_choose",null);recognitionDialog=new AlertDialog.Builder(this).setTitle("Hangisini söylediniz?").setItems(options.toArray(new String[0]),new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){recognitionDialog=null;dispatchSpoken(options.get(w));}}).setNegativeButton("Yeniden dinle",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){recognitionDialog=null;beginListening();}}).create();recognitionDialog.show();return;
        }
        if(low){final String text=top;recognitionDialog=new AlertDialog.Builder(this).setTitle("Doğru mu duydum?").setMessage(text).setPositiveButton("Evet",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){recognitionDialog=null;dispatchSpoken(text);}}).setNegativeButton("Tekrar dinle",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){recognitionDialog=null;beginListening();}}).create();recognitionDialog.show();say("","speech_choose",null);return;}
        dispatchSpoken(top);
    }
    private void dispatchSpoken(String raw){spokenCommand=true;try{dispatch(raw);}finally{spokenCommand=false;}}
    private void beginListening(){
        if(voice!=null)voice.beginTurn();if(phone!=null)phone.cancel();cancelWork();deferredAction=null;
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},810);return;}
        startRecognition(false,0);
    }
    @Override public void onClick(View v){
        if(listening){if(!waitingFinal&&recognizer!=null){waitingFinal=true;recognitionStatus.setText("ÇÖZÜMLENİYOR · sonucu bekliyorum");handler.removeCallbacks(speechTimeout);handler.postDelayed(speechTimeout,10000);try{recognizer.stopListening();}catch(Exception e){recognitionFailure(5);}}else{stopRecognition();say("","cancel",null);}return;}
        beginListening();
    }
    private void alternativeListening(){
        stopRecognition();voice.beginTurn();if(phone!=null)phone.cancel();cancelWork();
        Intent intent=RecognitionConfig.intent(!isOnline());
        try{startActivityForResult(intent,812);}catch(Exception e){recognitionStatus.setText("Alternatif ses tanıma hizmeti bulunamadı.");say("","recognition_unavailable",null);}
    }
    @Override public void onRequestPermissionsResult(int code,String[] permissions,int[] grants){if(phone!=null&&phone.permissions(code,grants))return;if(code==810){if(grants.length>0&&grants[0]==PackageManager.PERMISSION_GRANTED)beginListening();else local("Mikrofon izni kapalı","YAZ düğmesiyle komut verebilirsiniz. Telefonun uygulama izinlerinden mikrofonu açabilirsiniz.");return;}super.onRequestPermissionsResult(code,permissions,grants);}
    private void stopRecognition(){recognitionEpoch++;listening=false;waitingFinal=false;handler.removeCallbacks(speechTimeout);if(recognizer!=null){try{recognizer.cancel();recognizer.destroy();}catch(Exception ignored){}recognizer=null;}if(micLevel!=null)micLevel.setProgress(0);}
    private void recognitionFailure(int code){stopRecognition();if(dead)return;recognitionStatus.setText("DİNLEME SONA ERDİ · "+RecognitionConfig.error(code));meta.setText("Tanıma kodu: "+code+" · Son duyulan metin yukarıda.");say("",code==9?"mic_denied":"speech_error",null);}
    private void startRecognition(final boolean forceDefault,final int attempt){
        stopRecognition();final int recognitionId=recognitionEpoch;final boolean offline=!isOnline();
        final boolean onDevice=offline&&!forceDefault&&Build.VERSION.SDK_INT>=31&&SpeechRecognizer.isOnDeviceRecognitionAvailable(this);
        try {
            if(onDevice)recognizer=SpeechRecognizer.createOnDeviceSpeechRecognizer(this);
            else {if(!SpeechRecognizer.isRecognitionAvailable(this)){recognitionFailure(5);return;}recognizer=SpeechRecognizer.createSpeechRecognizer(this);}
            recognizer.setRecognitionListener(new RecognitionListener(){
                public void onReadyForSpeech(Bundle b){if(recognitionId!=recognitionEpoch)return;recognitionStatus.setText("DİNLİYOR · şimdi konuşun; bitirince DİNLE'ye tekrar dokunabilirsiniz.");}
                public void onBeginningOfSpeech(){if(recognitionId==recognitionEpoch)recognitionStatus.setText("SES ALGILANDI · konuşmanızı dinliyorum");}
                public void onRmsChanged(float f){if(recognitionId==recognitionEpoch)micLevel.setProgress(Math.max(0,Math.min(100,(int)((f+2)*7))));}
                public void onBufferReceived(byte[] b){}
                public void onEndOfSpeech(){if(recognitionId!=recognitionEpoch)return;waitingFinal=true;recognitionStatus.setText("ÇÖZÜMLENİYOR · komut sonucu bekleniyor");handler.removeCallbacks(speechTimeout);handler.postDelayed(speechTimeout,10000);}
                public void onPartialResults(Bundle b){if(recognitionId!=recognitionEpoch)return;ArrayList<String> parts=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(parts!=null&&!parts.isEmpty())heard.setText("Duyuluyor: "+parts.get(0));}
                public void onEvent(int t,Bundle b){}
                public void onError(int code){if(recognitionId!=recognitionEpoch)return;
                    if(attempt==0&&(code==8||(onDevice&&(code==12||code==13||code==5)))){stopRecognition();final int retryId=recognitionEpoch;recognitionStatus.setText("Konuşma hizmeti yeniden hazırlanıyor…");handler.postDelayed(new Runnable(){public void run(){if(!dead&&retryId==recognitionEpoch)startRecognition(true,1);}},600);return;}recognitionFailure(code);
                }
                public void onResults(Bundle b){if(recognitionId!=recognitionEpoch)return;ArrayList<String> texts=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);float[] scores=b.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES);stopRecognition();recognitionStatus.setText("KONUŞMA ALINDI");acceptSpeech(texts,scores);}
            });
            listening=true;waitingFinal=false;heard.setText("Duyduğum: —");recognitionStatus.setText("MİKROFON HAZIRLANIYOR…");recognizer.startListening(RecognitionConfig.intent(offline));handler.postDelayed(speechTimeout,30000);
        }catch(Exception e){recognitionFailure(5);}
    }
}
