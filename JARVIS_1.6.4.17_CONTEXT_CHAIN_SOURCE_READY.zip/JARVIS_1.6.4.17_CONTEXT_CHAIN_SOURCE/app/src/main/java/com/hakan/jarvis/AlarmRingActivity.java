package com.hakan.jarvis;
import android.app.*;import android.os.*;import android.content.*;import android.view.*;import android.widget.*;import org.json.JSONObject;
public final class AlarmRingActivity extends Activity {
 int id;BroadcastReceiver receiver=new BroadcastReceiver(){public void onReceive(Context c,Intent i){finish();}};
 public void onCreate(Bundle b){super.onCreate(b);if(Build.VERSION.SDK_INT>=27){setShowWhenLocked(true);setTurnScreenOn(true);}else getWindow().addFlags(0x00080000|0x00200000);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);id=getIntent().getIntExtra("id",-1);JSONObject item=AlarmStore.get(this,id);
 LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setGravity(Gravity.CENTER);box.setPadding(32,32,32,32);box.setBackgroundColor(0xff070d12);TextView text=new TextView(this);text.setTextColor(0xff00deef);text.setTextSize(28);text.setGravity(Gravity.CENTER);text.setText("JARVIS\nALARM\n\n"+(item==null?"Alarm sona erdi":item.optString("label")));box.addView(text);Button stop=new Button(this);stop.setText("ALARMI DURDUR");box.addView(stop);stop.setOnClickListener(new View.OnClickListener(){public void onClick(View v){stopService(new Intent(AlarmRingActivity.this,AlarmRingService.class));finish();}});setContentView(box);
 if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,new IntentFilter("com.hakan.jarvis.ALARM_STOPPED"),Context.RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,new IntentFilter("com.hakan.jarvis.ALARM_STOPPED"));
 }
 public void onDestroy(){try{unregisterReceiver(receiver);}catch(Exception ignored){}super.onDestroy();}
}
