package com.hakan.jarvis;
import android.app.*;import android.content.*;import android.os.*;import org.json.*;import java.util.*;
/** Persistent one-shot alarms. Only confirmed requests enter this store. */
public final class AlarmStore {
 static final String PREF="jarvis_alarms_v1",CHANNEL="jarvis_alarms";
 static android.content.SharedPreferences prefs(Context c){return c.getSharedPreferences(PREF,0);}
 public static boolean permitted(Context c){
  // Current JARVIS deliberately targets API 28. Android only enforces the special
  // exact-alarm access on apps targeting API 31+, so legacy-target builds do not
  // need to ask the user for “Alarms & reminders” access.
  if(Build.VERSION.SDK_INT<31||c.getApplicationInfo().targetSdkVersion<31)return true;
  return ((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).canScheduleExactAlarms();
 }
 public static void channel(Context c){if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(CHANNEL,"JARVIS alarmları",NotificationManager.IMPORTANCE_HIGH);ch.setDescription("Onayladığınız tarihli alarmlar");ch.setSound(null,null);ch.enableVibration(true);((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);}}
 public static boolean notifications(Context c){channel(c);NotificationManager n=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);if(Build.VERSION.SDK_INT>=24&&!n.areNotificationsEnabled())return false;if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=n.getNotificationChannel(CHANNEL);if(ch!=null&&ch.getImportance()==NotificationManager.IMPORTANCE_NONE)return false;}return true;}
 static JSONObject all(Context c){try{return new JSONObject(prefs(c).getString("items","{}"));}catch(Exception e){return new JSONObject();}}
 static void save(Context c,JSONObject j){if(!prefs(c).edit().putString("items",j.toString()).commit())throw new IllegalStateException("Alarm kaydı yazılamadı");}
 public static synchronized List<JSONObject> list(Context c){ArrayList<JSONObject> list=new ArrayList<JSONObject>();JSONObject j=all(c);Iterator<String> it=j.keys();while(it.hasNext()){JSONObject a=j.optJSONObject(it.next());if(a!=null)list.add(a);}Collections.sort(list,new Comparator<JSONObject>(){public int compare(JSONObject a,JSONObject b){return Long.compare(a.optLong("when"),b.optLong("when"));}});return list;}
 static PendingIntent fire(Context c,int id){return PendingIntent.getBroadcast(c,id,new Intent(c,AlarmReceiver.class).setAction("com.hakan.jarvis.FIRE").putExtra("id",id),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 static PendingIntent view(Context c,int id){return PendingIntent.getActivity(c,id,new Intent(c,AlarmRingActivity.class).putExtra("id",id),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 static void arm(Context c,int id,long when){((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).setAlarmClock(new AlarmManager.AlarmClockInfo(when,PendingIntent.getActivity(c,0,new Intent(c,HybridActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE)),fire(c,id));}
 public static synchronized int schedule(Context c,long when,String label)throws Exception{
  if(!permitted(c))throw new SecurityException("Kesin alarm izni kapalı");if(when<=System.currentTimeMillis()+250)throw new IllegalArgumentException("Alarm saati geçti; yeniden saat belirtin.");
  JSONObject j=all(c);if(j.length()>=50)throw new IllegalStateException("En fazla 50 alarm kaydı tutulabilir; eski kayıtları silin.");int id=prefs(c).getInt("next",100)+1;if(!prefs(c).edit().putInt("next",id).commit())throw new IllegalStateException("Kayıt hatası");
  JSONObject a=new JSONObject().put("id",id).put("when",when).put("label",label).put("state","scheduled");j.put(""+id,a);save(c,j);
  try{arm(c,id,when);}catch(Exception e){j.remove(""+id);save(c,j);throw e;}return id;
 }
 public static synchronized void cancel(Context c,int id){((AlarmManager)c.getSystemService(Context.ALARM_SERVICE)).cancel(fire(c,id));JSONObject j=all(c);j.remove(""+id);save(c,j);if(prefs(c).getInt("ringing",-1)==id)c.stopService(new Intent(c,AlarmRingService.class));}
 public static synchronized JSONObject get(Context c,int id){return all(c).optJSONObject(""+id);}
 public static synchronized boolean due(Context c,int id){JSONObject j=all(c),a=j.optJSONObject(""+id);if(a==null||!a.optString("state").equals("scheduled")||a.optLong("when")>System.currentTimeMillis()+1000)return false;try{a.put("state","ringing");save(c,j);return true;}catch(Exception e){return false;}}
 public static synchronized void state(Context c,int id,String state){try{JSONObject j=all(c),a=j.optJSONObject(""+id);if(a!=null){a.put("state",state);save(c,j);}}catch(Exception ignored){}}
 public static synchronized void restore(Context c){if(!permitted(c))return;for(JSONObject a:list(c)){int id=a.optInt("id");if(a.optString("state").equals("scheduled")){if(a.optLong("when")<System.currentTimeMillis()-60000){state(c,id,"missed");continue;}try{arm(c,id,Math.max(System.currentTimeMillis()+100,a.optLong("when")));}catch(Exception e){state(c,id,"error");}}}}
}
