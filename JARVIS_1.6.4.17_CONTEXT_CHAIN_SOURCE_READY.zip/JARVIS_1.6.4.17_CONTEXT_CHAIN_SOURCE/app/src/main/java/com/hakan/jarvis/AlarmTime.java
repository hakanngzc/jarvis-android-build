package com.hakan.jarvis;
import java.util.*;import java.util.regex.*;
/** Turkish clock expressions, intentionally excluding unsupported dated/repeating alarms. */
public final class AlarmTime {
 public final int hour,minute;public final String error,question;
 private AlarmTime(int h,int m,String e,String q){hour=h;minute=m;error=e;question=q;}
 static AlarmTime fail(String e,String q){return new AlarmTime(-1,-1,e,q);}
 static final String[] U={"sifir","bir","iki","uc","dort","bes","alti","yedi","sekiz","dokuz"};
 static final String[] T={"","on","yirmi","otuz","kirk","elli"};
 static String word(int n){return n<10?U[n]:T[n/10]+(n%10==0?"":" "+U[n%10]);}
 static int number(String s){
  if(s.trim().matches(".*[0-9] +[0-9].*"))return -1;
  s=s.trim().replace("'","").replace(" ","");
  for(int n=0;n<60;n++){String w=word(n).replace(" ","");if(n==4&&(s.equals("dorde")||s.equals("dordu")))return n;
   for(String base:new String[]{w,Integer.toString(n),String.format(Locale.US,"%02d",n)})if(s.equals(base)||s.matches(Pattern.quote(base)+"(?:ya|ye|yi|yu|a|e|i|u|da|de|ta|te)"))return n;
  }return -1;
 }
 public static AlarmTime parse(String raw){
  String s=CommandLanguage.clean(raw).replace("ogleden sonra","aksam").replaceAll("\\balarm(?:i|imi|im)\\b","alarm");
  s=s.replaceAll("(\\S) bir alarm\\b","$1 alarm");
  if(s.matches(".*\\b(yarin|bugun|pazartesi|sali|carsamba|persembe|cuma|cumartesi|pazar|her|sonra|hafta)\\b.*"))return fail("Tarihli, süreli ve tekrarlı alarmları Saat uygulamasından ayarlayın. Burada yalnızca saat söyleyin.","");
  boolean am=s.matches(".*\\bsabah\\b.*"),pm=s.matches(".*\\baksam\\b.*"),night=s.matches(".*\\bgece\\b.*")&&!s.matches(".*\\b(?:ceyrek|on|bes|yirmi|\\d+) gece\\b.*"),noon=s.matches(".*\\boglen\\b.*");
  if((am?1:0)+(pm?1:0)+(night?1:0)+(noon?1:0)>1)return fail("Sabah ve akşam ifadeleri çelişiyor. Tek saat belirtin.","time");
  s=s.replaceAll("\\b(?:sabah|aksam|oglen|saat|alarm|kur|ayarla|ekle|icin|beni|uyandir)\\b"," ");if(night)s=s.replaceAll("\\bgece\\b"," ");
  s=s.replaceAll("\\s+"," ").trim().replaceAll("[.,]+$","");
  if(s.length()==0)return fail("Alarmı kaça ayarlayayım? Örneğin sabah yedi buçuk.","time");
  int h=-1,m=0,subtract=0;boolean explicit=s.matches("0?[0-9].*()()()");
  Matcher numeric=Pattern.compile("^(\\d{1,2})\\s*[:.]\\s*(\\d{1,2})(?:'?(?:ya|ye|a|e|da|de|ta|te))?$").matcher(s);
  if(numeric.matches()){h=Integer.parseInt(numeric.group(1));m=Integer.parseInt(numeric.group(2));explicit=true;}
  else if(s.matches(".* (?:bucuk|bucuga|bucukta)$")){h=number(s.replaceFirst(" (?:bucuk|bucuga|bucukta)$",""));m=30;}
  else if(s.endsWith(" kala")||s.endsWith(" gece")||s.endsWith(" geciyor")){
   boolean before=s.endsWith(" kala");String body=s.replaceFirst(" (?:kala|gece|geciyor)$","");String[] bits=body.split(" ");
   for(int i=1;i<bits.length;i++){String left=join(bits,0,i),right=join(bits,i,bits.length);int a=number(left),b=right.equals("ceyrek")?15:number(right);if(a>=0&&a<=23&&b>=1&&b<60){if(h!=-1)return fail("Saat belirsiz. 07:30 gibi söyleyin.","time");h=a;m=before?0:b;subtract=before?b:0;}}
  }else{
   h=number(s);if(h<0){String[] bits=s.split(" ");for(int i=1;i<bits.length;i++){int a=number(join(bits,0,i)),b=number(join(bits,i,bits.length));if(a>=0&&a<=23&&b>=0&&b<60){if(h!=-1)return fail("Saati netleştirin. Örneğin 19:30.","time");h=a;m=b;}}}
  }
  if(h<0||h>23||m<0||m>59)return fail("Saati anlayamadım. ‘Sabah yedi otuz’ veya ‘19:30’ diyebilirsiniz.","time");
  if(am&&h>=12)return fail("Sabah ile saat uyuşmuyor. Saati yeniden belirtin.","time");
  if(pm){if(h==0)return fail("Akşam için 18:00 gibi 24 saat biçimini kullanın.","time");if(h<12)h+=12;}
  if(noon){if(h>=1&&h<=5)h+=12;if(h<12||h>17)return fail("Öğlen ile saat uyuşmuyor.","time");}
  if(night){if(h==12)h=0;else if(h==11)h=23;else if(h>5&&h<20)return fail("Gece saatini 24 saat biçiminde söyleyin.","time");}
  if(!am&&!pm&&!night&&!noon&&!explicit&&h>=1&&h<=12)return fail("Sabah mı, akşam mı? ‘Sabah’ veya ‘akşam’ diye yanıtlayın.","period");
  int total=(h*60+m-subtract+1440)%1440;return new AlarmTime(total/60,total%60,null,"");
 }
 private static String join(String[] a,int from,int to){StringBuilder b=new StringBuilder();for(int i=from;i<to;i++){if(b.length()>0)b.append(' ');b.append(a[i]);}return b.toString();}
}
