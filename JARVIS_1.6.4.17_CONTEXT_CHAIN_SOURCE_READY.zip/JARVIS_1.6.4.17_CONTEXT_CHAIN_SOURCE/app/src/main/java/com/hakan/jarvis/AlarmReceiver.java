package com.hakan.jarvis;
import android.content.*;import android.os.Build;
public final class AlarmReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent i){if("com.hakan.jarvis.FIRE".equals(i.getAction())){int id=i.getIntExtra("id",-1);if(!AlarmStore.due(c,id))return;Intent service=new Intent(c,AlarmRingService.class).putExtra("id",id);try{if(Build.VERSION.SDK_INT>=26)c.startForegroundService(service);else c.startService(service);}catch(Exception e){AlarmStore.state(c,id,"error");}}else AlarmStore.restore(c);}
}
