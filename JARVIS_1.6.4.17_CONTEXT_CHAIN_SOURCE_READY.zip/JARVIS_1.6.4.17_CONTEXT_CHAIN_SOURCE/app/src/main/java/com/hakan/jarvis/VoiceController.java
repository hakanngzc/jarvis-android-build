package com.hakan.jarvis;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.*;
import android.os.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

/** Serial playback with bounded neural generation, same-voice offline fallbacks and action gating. */
public final class VoiceController {
    public interface Listener {void state(String state,String detail);}
    private static final class Job {
        final String text,key;final boolean online;final Runnable after;final int turn;
        boolean fallbackTried;
        Job(String t,String k,boolean o,Runnable a,int n){text=t;key=k;online=o;after=a;turn=n;}
    }
    private final Context context;
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final ArrayDeque<Job> queue=new ArrayDeque<Job>();
    private final AudioManager audio;
    private final File cache;
    private final Listener listener;
    private volatile NeuralSpeech neural;
    private volatile int turn;
    private boolean destroyed,busy;
    private long retryOnlineAt;
    private MediaPlayer player;
    private Future<?> future;
    private Runnable watchdog;
    private String lastText="",lastKey="wake";
    private final AudioManager.OnAudioFocusChangeListener focus=new AudioManager.OnAudioFocusChangeListener(){public void onAudioFocusChange(int change){if(change<0)main.post(new Runnable(){public void run(){stop();listener.state("DURDU","Başka bir uygulama ses odağını aldı.");}});}};
    public VoiceController(Context c,Listener l){context=c.getApplicationContext();listener=l;audio=(AudioManager)c.getSystemService(Context.AUDIO_SERVICE);cache=new File(c.getFilesDir(),"natural-voice-cache");cache.mkdirs();}
    public boolean isBusy(){return busy;}
    public void beginTurn(){stop();}
    public void speak(String text,String fallback,boolean online,Runnable after){
        if(destroyed)return;String t=text==null?"":text.trim();if(t.length()>700)t=t.substring(0,660)+". Ayrıntılar ekranda efendim.";
        String key=fallback!=null&&fallback.matches("[a-z_]+")?fallback:"error";
        lastText=t;lastKey=key;
        queue.add(new Job(t,key,online,after,turn));if(!busy)next();
    }
    public void repeat(boolean online){String text=lastText,key=lastKey;beginTurn();speak(text,key,online,null);}
    private void next(){
        if(destroyed||queue.isEmpty()){busy=false;return;}final Job job=queue.removeFirst();if(job.turn!=turn){next();return;}busy=true;listener.state("HAZIRLANIYOR","");
        if(job.text.length()==0){play(job,null,true);return;}
        future=worker.submit(new Runnable(){public void run(){
            File output=null;boolean fallback=true;
            try{
                String key=NeuralSpeech.digest("AhmetNeural|-4%|-2Hz|"+job.text);File file=new File(cache,key+".mp3");
                if(file.isFile()&&file.length()>1500){output=file;fallback=false;file.setLastModified(System.currentTimeMillis());}
                else if(job.online&&System.currentTimeMillis()>retryOnlineAt){
                    if(neural==null)neural=new NeuralSpeech();byte[] data=neural.synthesize(job.text);
                    if(Thread.currentThread().isInterrupted()||job.turn!=turn)return;
                    File tmp=new File(cache,key+".tmp");FileOutputStream out=new FileOutputStream(tmp);try{out.write(data);out.getFD().sync();}finally{out.close();}
                    if(!tmp.renameTo(file)){tmp.delete();throw new IOException("Audio cache write");}output=file;fallback=false;trim();
                }
            }catch(Exception e){if(Thread.currentThread().isInterrupted()||job.turn!=turn)return;retryOnlineAt=System.currentTimeMillis()+60000;}
            final File file=output;final boolean fromBank=fallback;main.post(new Runnable(){public void run(){if(destroyed||job.turn!=turn)return;play(job,file,fromBank);}});
        }});
    }
    private void play(final Job job,final File file,final boolean fromBank){
        if(destroyed||job.turn!=turn)return;
        if(audio.getStreamVolume(AudioManager.STREAM_MUSIC)==0){fail(job,"Medya sesi kapalı. Ses düğmesiyle yükseltip SESİ TEKRARLA'ya dokunun.");return;}
        if(audio.requestAudioFocus(focus,AudioManager.STREAM_MUSIC,AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)!=AudioManager.AUDIOFOCUS_REQUEST_GRANTED){fail(job,"Ses odağı alınamadı. SESİ TEKRARLA ile yeniden deneyin.");return;}
        releasePlayer();
        try{
            final MediaPlayer mp=new MediaPlayer();player=mp;
            mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
            if(fromBank){AssetFileDescriptor fd=context.getAssets().openFd("voice/"+job.key+".mp3");try{mp.setDataSource(fd.getFileDescriptor(),fd.getStartOffset(),fd.getLength());}finally{fd.close();}}
            else mp.setDataSource(file.getAbsolutePath());
            mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener(){public void onPrepared(MediaPlayer m){
                if(job.turn!=turn||player!=m)return;clearWatchdog();listener.state("KONUŞUYOR",fromBank?"Gömülü doğal ses":"Doğal Türkçe ses");
                try{m.start();watchdog=new Runnable(){public void run(){if(job.turn==turn&&player==mp)fail(job,"Ses oynatma zaman aşımı.");}};main.postDelayed(watchdog,100000);}catch(Exception e){fail(job,"Ses başlatılamadı.");}
            }});
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener(){public void onCompletion(MediaPlayer m){if(job.turn!=turn||player!=m)return;complete(job);}});
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener(){public boolean onError(MediaPlayer m,int what,int extra){
                if(job.turn!=turn||player!=m)return true;
                releasePlayer();if(!fromBank&&!job.fallbackTried){job.fallbackTried=true;if(file!=null)file.delete();play(job,null,true);}else fail(job,"Ses dosyası oynatılamadı. SESİ TEKRARLA ile deneyin.");return true;
            }});
            watchdog=new Runnable(){public void run(){if(job.turn!=turn||player!=mp)return;releasePlayer();if(!fromBank&&!job.fallbackTried){job.fallbackTried=true;play(job,null,true);}else fail(job,"Ses hazırlanamadı.");}};main.postDelayed(watchdog,5000);mp.prepareAsync();
        }catch(Exception e){releasePlayer();if(!fromBank&&!job.fallbackTried){job.fallbackTried=true;play(job,null,true);}else fail(job,"Ses oynatılamadı. İşlem başlatılmadı.");}
    }
    private void complete(Job job){releasePlayer();audio.abandonAudioFocus(focus);busy=false;listener.state("HAZIR","");
        if(job.after!=null&&job.turn==turn&&!destroyed){try{job.after.run();}catch(Exception e){listener.state("İŞLEM HATASI","İlgili uygulama başlatılamadı.");}}if(job.turn==turn&&!busy)next();
    }
    private void fail(Job job,String message){releasePlayer();audio.abandonAudioFocus(focus);busy=false;queue.clear();listener.state("SES UYARISI",message);}
    private void clearWatchdog(){if(watchdog!=null){main.removeCallbacks(watchdog);watchdog=null;}}
    private void releasePlayer(){clearWatchdog();if(player!=null){MediaPlayer old=player;player=null;try{old.setOnPreparedListener(null);old.setOnCompletionListener(null);old.setOnErrorListener(null);old.release();}catch(Exception ignored){}}}
    public void stop(){turn++;queue.clear();if(future!=null)future.cancel(true);if(neural!=null)neural.cancel();releasePlayer();audio.abandonAudioFocus(focus);busy=false;}
    public void destroy(){destroyed=true;stop();worker.shutdownNow();if(neural!=null)neural.close();main.removeCallbacksAndMessages(null);}
    private void trim(){File[] files=cache.listFiles();if(files==null)return;Arrays.sort(files,new Comparator<File>(){public int compare(File a,File b){return Long.compare(a.lastModified(),b.lastModified());}});long total=0;for(File f:files)total+=f.length();int count=files.length;for(File f:files){if(count<=100&&total<=32*1024*1024)break;long n=f.length();if(f.delete()){count--;total-=n;}}}
}
