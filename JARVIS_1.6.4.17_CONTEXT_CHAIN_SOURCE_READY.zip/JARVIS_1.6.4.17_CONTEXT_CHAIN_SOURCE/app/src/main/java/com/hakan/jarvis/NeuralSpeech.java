package com.hakan.jarvis;

import okhttp3.*;
import okio.ByteString;
import java.io.*;
import java.util.*;
import java.text.SimpleDateFormat;
import java.security.MessageDigest;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicReference;

/** Network-only neural speech. No Android TextToSpeech and no account credential. */
public final class NeuralSpeech {
    private static final String CLIENT="6A5AA1D4EAFF4E9FB37E23D68491D6F4"; // public Edge read-aloud client id
    private static final String VERSION="1-143.0.3650.75";
    private final OkHttpClient client;
    private volatile WebSocket socket;
    private volatile CountDownLatch waiting;
    public NeuralSpeech(){this(new OkHttpClient.Builder().connectTimeout(5,TimeUnit.SECONDS).readTimeout(10,TimeUnit.SECONDS).build());}
    public NeuralSpeech(OkHttpClient c){client=c;}
    public static String xml(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;").replaceAll("[\\x00-\\x08\\x0B\\x0C\\x0E-\\x1F]"," ");}
    public static String digest(String value)throws Exception{byte[] bytes=MessageDigest.getInstance("SHA-256").digest(value.getBytes("UTF-8"));StringBuilder b=new StringBuilder();for(byte x:bytes)b.append(String.format(Locale.US,"%02x",x&255));return b.toString();}
    public static String token(long ms)throws Exception{long seconds=ms/1000+11644473600L;seconds-=seconds%300;return digest(Long.toString(seconds*10000000L)+CLIENT).toUpperCase(Locale.US);}
    private static String uuid(){return UUID.randomUUID().toString().replace("-","");}
    private static String stamp(){SimpleDateFormat f=new SimpleDateFormat("EEE MMM dd yyyy HH:mm:ss 'GMT+0000 (Coordinated Universal Time)'",Locale.US);f.setTimeZone(TimeZone.getTimeZone("UTC"));return f.format(new Date());}
    public void cancel(){WebSocket ws=socket;if(ws!=null)ws.cancel();CountDownLatch l=waiting;if(l!=null)l.countDown();}
    public byte[] synthesize(final String text)throws Exception {
        if(text==null||text.trim().length()==0||text.length()>700)throw new IOException("Speech length");
        final CountDownLatch done=new CountDownLatch(1);waiting=done;
        final ByteArrayOutputStream audio=new ByteArrayOutputStream();
        final AtomicReference<Throwable> error=new AtomicReference<Throwable>();
        final boolean[] finished={false};
        String endpoint="https://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1?TrustedClientToken="+CLIENT+"&ConnectionId="+uuid()+"&Sec-MS-GEC="+token(System.currentTimeMillis())+"&Sec-MS-GEC-Version="+VERSION;
        Request req=new Request.Builder().url(endpoint).header("User-Agent","Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0").header("Origin","chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold").header("Pragma","no-cache").header("Cache-Control","no-cache").header("Accept-Language","en-US,en;q=0.9").header("Cookie","muid="+uuid().toUpperCase(Locale.US)+";").build();
        WebSocket ws=client.newWebSocket(req,new WebSocketListener(){
            @Override public void onOpen(WebSocket ws,Response response){
                ws.send("X-Timestamp:"+stamp()+"\r\nContent-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n{\"context\":{\"synthesis\":{\"audio\":{\"metadataoptions\":{\"sentenceBoundaryEnabled\":\"false\",\"wordBoundaryEnabled\":\"false\"},\"outputFormat\":\"audio-24khz-48kbitrate-mono-mp3\"}}}}\r\n");
                ws.send("X-RequestId:"+uuid()+"\r\nContent-Type:application/ssml+xml\r\nX-Timestamp:"+stamp()+"Z\r\nPath:ssml\r\n\r\n<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='en-US'><voice name='tr-TR-AhmetNeural'><prosody pitch='-2Hz' rate='-4%' volume='+0%'>"+xml(text)+"</prosody></voice></speak>");
            }
            @Override public void onMessage(WebSocket ws,String s){if(s.contains("Path:turn.end")){finished[0]=true;done.countDown();ws.close(1000,"done");}}
            @Override public void onMessage(WebSocket ws,ByteString data){
                byte[] b=data.toByteArray();if(b.length<2)return;int len=((b[0]&255)<<8)|(b[1]&255);
                if(len+2>b.length){error.set(new IOException("Bad audio frame"));done.countDown();ws.cancel();return;}
                try {String headers=new String(b,2,len,"UTF-8");if(!headers.contains("Path:audio"))return;
                    if(audio.size()+b.length-len-2>1500000){error.set(new IOException("Audio too large"));done.countDown();ws.cancel();return;}
                    audio.write(b,len+2,b.length-len-2);
                }catch(Exception e){error.set(e);done.countDown();ws.cancel();}
            }
            @Override public void onFailure(WebSocket ws,Throwable t,Response r){error.set(t);done.countDown();}
            @Override public void onClosed(WebSocket ws,int code,String reason){done.countDown();}
        });socket=ws;
        try{if(!done.await(13,TimeUnit.SECONDS))throw new IOException("Speech timeout");if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();if(error.get()!=null||!finished[0]||audio.size()<1500)throw new IOException("Neural speech unavailable",error.get());return audio.toByteArray();}
        finally{ws.cancel();if(socket==ws)socket=null;if(waiting==done)waiting=null;}
    }
    public void close(){cancel();client.dispatcher().executorService().shutdownNow();client.connectionPool().evictAll();}
}
