package com.hakan.jarvis;
import android.app.*;import android.content.*;import android.media.*;import android.os.*;import android.content.res.AssetFileDescriptor;import org.json.JSONObject;
public final class AlarmRingService extends Service {
 MediaPlayer player;AudioManager audio;PowerManager.WakeLock lock;Handler h=new Handler();int current=-1;boolean stopped;
 final AudioManager.OnAudioFocusChangeListener focus=new AudioManager.OnAudioFocusChangeListener(){public void onAudioFocusChange(int change){/* Alarm remains visible; system decides ducking. */}};
 public IBinder onBind(Intent i){return null;}
 public int onStartCommand(Intent i,int flags,int startId){
  int id=i==null?-1:i.getIntExtra("id",-1);if(i!=null&&"STOP".equals(i.getAction())){if(id==current)stopSelf();return START_NOT_STICKY;}
  JSONObject item=AlarmStore.get(this,id);if(item==null||!item.optString("state").equals("ringing")){stopSelf();return START_NOT_STICKY;}
  if(current!=-1&&current!=id)AlarmStore.state(this,current,"overlapped");current=id;AlarmStore.channel(this);AlarmStore.prefs(this).edit().putInt("ringing",id).putLong("lastFire",System.currentTimeMillis()).apply();
  Intent stop=new Intent(this,AlarmRingService.class).setAction("STOP").putExtra("id",id);PendingIntent stopPi=PendingIntent.getService(this,id,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,AlarmStore.CHANNEL):new Notification.Builder(this);
  b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("JARVIS · Alarm").setContentText(item.optString("label")).setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_MAX).setOngoing(true).setContentIntent(AlarmStore.view(this,id)).addAction(android.R.drawable.ic_media_pause,"DURDUR",stopPi);
  NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(Build.VERSION.SDK_INT<34||nm.canUseFullScreenIntent())b.setFullScreenIntent(AlarmStore.view(this,id),true);
  startForeground(7301,b.build());
  if(lock==null){lock=((PowerManager)getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"jarvis:alarm");}if(lock.isHeld())lock.release();lock.acquire(10*60*1000L);
  h.removeCallbacksAndMessages(null);h.postDelayed(new Runnable(){public void run(){stopSelf();}},10*60*1000L);
  if(player!=null)player.release();audio=(AudioManager)getSystemService(AUDIO_SERVICE);audio.requestAudioFocus(focus,AudioManager.STREAM_ALARM,AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
  try{player=new MediaPlayer();player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());AssetFileDescriptor fd=getAssets().openFd("voice/alarm_ring.mp3");try{player.setDataSource(fd.getFileDescriptor(),fd.getStartOffset(),fd.getLength());}finally{fd.close();}player.setLooping(true);player.setOnPreparedListener(new MediaPlayer.OnPreparedListener(){public void onPrepared(MediaPlayer p){p.start();AlarmStore.prefs(AlarmRingService.this).edit().putLong("lastSoundStart",System.currentTimeMillis()).apply();}});player.setOnErrorListener(new MediaPlayer.OnErrorListener(){public boolean onError(MediaPlayer p,int w,int e){AlarmStore.state(AlarmRingService.this,current,"audio_error");return true;}});player.prepareAsync();}catch(Exception e){AlarmStore.state(this,id,"audio_error");}
  return START_NOT_STICKY;
 }
 public void onDestroy(){h.removeCallbacksAndMessages(null);if(player!=null)player.release();if(audio!=null)audio.abandonAudioFocus(focus);if(lock!=null&&lock.isHeld())lock.release();JSONObject previous=AlarmStore.get(this,current);if(previous!=null&&previous.optString("state").equals("ringing"))AlarmStore.state(this,current,"finished");AlarmStore.prefs(this).edit().remove("ringing").apply();stopForeground(true);sendBroadcast(new Intent("com.hakan.jarvis.ALARM_STOPPED").setPackage(getPackageName()));super.onDestroy();}
}
