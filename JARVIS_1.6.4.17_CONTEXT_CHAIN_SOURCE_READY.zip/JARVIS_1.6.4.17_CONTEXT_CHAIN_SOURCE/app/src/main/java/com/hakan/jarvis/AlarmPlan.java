package com.hakan.jarvis;
import java.util.*;import java.util.regex.*;import java.text.SimpleDateFormat;
/** One-shot alarm resolution with an injectable clock and timezone. */
public final class AlarmPlan {
 public final String error,question,context,zone;public final int hour,minute;public final long when;
 private AlarmPlan(String e,String q,String c,int h,int m,long w,TimeZone z){error=e;question=q;context=c;hour=h;minute=m;when=w;zone=z.getID();}
 static AlarmPlan fail(String e,String q,String c,TimeZone z){return new AlarmPlan(e,q,c,-1,-1,0,z);}
 static final String[] DAYS={"pazar","pazartesi","sali","carsamba","persembe","cuma","cumartesi"};
 public static String context(String raw){String s=CommandLanguage.clean(raw);Matcher m=Pattern.compile("\\b(yarin|bugun|pazartesi|sali|carsamba|persembe|cuma|cumartesi|pazar)\\b").matcher(s);return m.find()?m.group(1):"";}
 public static AlarmPlan parse(String raw,long now,TimeZone zone){
  String s=CommandLanguage.clean(raw);String ctx=context(s);
  if(s.matches(".*\\b(her|hafta|haftalik|gunluk|tekrarla)\\b.*"))return fail("Tekrarlı alarm bu sürümde yok. Tek bir gün ve saat söyleyin.","",ctx,zone);
  if(s.replace("ogleden sonra", "ogleden").matches(".*\\bsonra\\b.*")){
   String r=s.replaceAll("\\balarm(?:i|imi|im)?\\b|\\b(?:beni|uyandir|kur|ayarla|ekle|icin)\\b", " ").trim().replaceAll("\\s+"," ");
   Matcher m=Pattern.compile("^(?:(.+?) saat(?: (.+?) dakika)?|(.+?) dakika) sonra$").matcher(r);
   if(!m.matches())return fail("Süreyi ‘20 dakika sonra’ veya ‘iki saat sonra’ şeklinde söyleyin.","",ctx,zone);
   int h=m.group(1)==null?0:AlarmTime.number(m.group(1)),min=m.group(3)!=null?AlarmTime.number(m.group(3)):m.group(2)!=null?AlarmTime.number(m.group(2)):0;
   if(h<0||min<0||h*60+min<=0||h*60+min>7*24*60)return fail("Geçerli bir süre söyleyin; en az bir dakika olmalı.","",ctx,zone);
   long when=now+(h*60L+min)*60000L;Calendar c=Calendar.getInstance(zone);c.setTimeInMillis(when);return new AlarmPlan(null,"","sure",c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),when,zone);
  }
  Matcher dates=Pattern.compile("\\b(yarin|bugun|pazartesi|sali|carsamba|persembe|cuma|cumartesi|pazar)\\b").matcher(s);int n=0;while(dates.find())n++;
  if(n>1)return fail("Birden fazla gün duydum. Hangi güne alarm kurayım?","date","",zone);
  s=s.replaceAll("\\b(yarin|bugun|pazartesi|sali|carsamba|persembe|cuma|cumartesi|pazar)\\b","").replaceFirst("^bu +","").trim().replaceAll("\\s+"," ");
  AlarmTime time=AlarmTime.parse(s);if(time.error!=null)return fail(time.error,time.question,ctx,zone);
  Calendar c=Calendar.getInstance(zone);c.setTimeInMillis(now);int currentDay=c.get(Calendar.DAY_OF_WEEK);int add=0;
  if(ctx.equals("yarin"))add=1;else for(int i=0;i<DAYS.length;i++)if(ctx.equals(DAYS[i]))add=(i+1-currentDay+7)%7;
  c.add(Calendar.DAY_OF_YEAR,add);c.set(Calendar.HOUR_OF_DAY,time.hour);c.set(Calendar.MINUTE,time.minute);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
  if(c.get(Calendar.HOUR_OF_DAY)!=time.hour||c.get(Calendar.MINUTE)!=time.minute)return fail("Bu saat, saat dilimi değişimi nedeniyle o gün geçerli değil. Başka saat belirtin.","time",ctx,zone);
  if(c.getTimeInMillis()<=now){
   if(ctx.equals("bugun"))return fail("Bugün bu saat geçti. ‘Yarın’ diyebilir veya yeni bir saat söyleyebilirsiniz.","date",ctx,zone);
   c.add(Calendar.DAY_OF_YEAR,ctx.length()==0?1:7);
  }
  if(c.get(Calendar.HOUR_OF_DAY)!=time.hour||c.get(Calendar.MINUTE)!=time.minute)return fail("Bu saat, saat dilimi değişimi nedeniyle o gün geçerli değil. Başka saat belirtin.","time",ctx,zone);
  return new AlarmPlan(null,"",ctx,time.hour,time.minute,c.getTimeInMillis(),zone);
 }
 public String label(){SimpleDateFormat f=new SimpleDateFormat("dd.MM.yyyy EEEE HH:mm",new Locale("tr","TR"));f.setTimeZone(TimeZone.getTimeZone(zone));return f.format(new Date(when));}
}
