package com.hakan.jarvis;

import org.json.*;
import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;

/** Pure Java routing, bounded HTTPS fetching and dated disk cache. No Android or TTS dependency. */
public final class HybridEngine {
    public interface Transport { String get(String url) throws Exception; }
    public static final class Request {
        public final String kind, query;
        public Request(String k, String q) { kind=k; query=q; }
        public String key() { return kind+":"+normalize(query); }
    }
    public static final class Answer {
        public String title, text, source, url;
        public long fetchedAt;
        public boolean cached, stale;
        public Answer(String t,String body,String s,String u,long time) {title=t;text=body;source=s;url=u;fetchedAt=time;}
        JSONObject json() throws Exception {return new JSONObject().put("title",title).put("text",text).put("source",source).put("url",url).put("time",fetchedAt);}
        static Answer read(JSONObject j) throws Exception {return new Answer(j.getString("title"),j.getString("text"),j.getString("source"),j.getString("url"),j.getLong("time"));}
    }
    public static final class Unavailable extends Exception {
        public Unavailable(String message){super(message);}
    }
    private final File cache;
    private final Transport transport;
    public HybridEngine(File dir,Transport t) {cache=new File(dir,"hybrid-cache-v1.json");transport=t;}
    public static String normalize(String s) {
        return s.toLowerCase(new Locale("tr","TR")).replace('ı','i').replace('ş','s').replace('ğ','g').replace('ü','u').replace('ö','o').replace('ç','c').replace('’','\'').replaceAll("[?!.,]+$", "").trim().replaceAll("\\s+"," ");
    }
    public static String clean(String s) {return s.trim().replaceFirst("(?iu)^(hey )?[jc][ae]rvi[sz].? ", "").trim();}
    public static Request route(String raw,String city) {
        String s=clean(raw), n=normalize(s);
        if(n.matches("(?:su an )?saat(?: kac( oldu)?)?"))return new Request("time","");
        if(n.matches("(?:tarih|bugun(un tarihi| ayin kaci| hangi gun| tarih))$"))return new Request("date","");
        if(n.startsWith("hesapla ")) return new Request("calc",s.substring(8).trim());
        if(n.startsWith("not al ")) return new Request("note",s.substring(7).trim());
        if(n.matches("notlarim(i? [go].*)?|notlari [go].*$"))return new Request("notes","");
        if(n.matches("hibrit yardim|yardim|neler yapabilirsin"))return new Request("help","");
        if(n.matches("baglanti(?: durumu)?|internet var mi"))return new Request("status","");
        // Action verbs must stay with the existing command parser, even if an app/track name contains 'hava'.
        if(n.matches(".*\\b(?:ac|cal|ara|kapat|gonder|duraklat|durdur)\\s*$"))return null;
        if(n.contains("hava durumu")||n.matches(".*\\bhava(?:si)? (?:nasil|kac derece).*")) {
            String q=n.replace("hava durumu","").replaceAll("\\bhava(?:si)?\\b","")
                .replaceAll("\\b(bugun|su an|simdi|nasil|kac derece|nedir|lutfen|soyle|goster|bana)\\b","").trim();
            if(q.matches(".*\\b(yarin|hafta|haftalik)\\b.*"))return new Request("unsupportedWeather","");
            q=q.replaceAll("['’](?:da|de|ta|te|nin|nun|in|un)\\b","").replaceAll("\\s+"," ").trim();
            return new Request("weather",q.length()==0?city:q);
        }
        if(n.matches("(?:dolar|euro|sterlin|usd|eur|gbp)(?: kuru| kac| ne kadar| kac tl)?")) {
            return new Request("currency",n.startsWith("dolar")||n.startsWith("usd")?"USD":n.startsWith("euro")||n.startsWith("eur")?"EUR":"GBP");
        }
        if(n.startsWith("bilgi "))return new Request("wiki",s.substring(6).trim());
        if(n.startsWith("wikipedia "))return new Request("wiki",s.substring(10).trim());
        if(n.endsWith(" nedir")||n.endsWith(" kimdir"))return new Request("wiki",s.replaceFirst("(?iu)\\s+(nedir|kimdir)[?!.,]*$", "").trim());
        if(n.endsWith(" hakkinda bilgi"))return new Request("wiki",s.substring(0,s.length()-15).trim());
        return null;
    }
    public static long ttl(String kind){return kind.equals("weather")?30*60*1000L:kind.equals("currency")?12*60*60*1000L:7*24*60*60*1000L;}
    public synchronized Answer cached(Request r,long now) {
        try {
            JSONObject root=readCache();JSONObject entry=root.optJSONObject(r.key());if(entry==null)return null;
            Answer a=Answer.read(entry);a.cached=true;a.stale=now<a.fetchedAt||now-a.fetchedAt>ttl(r.kind);return a;
        } catch(Exception e){return null;}
    }
    public synchronized void clearCache(){if(cache.exists())cache.delete();}
    private JSONObject readCache() throws Exception {
        if(!cache.isFile()||cache.length()>600000)return new JSONObject();
        FileInputStream in=new FileInputStream(cache);try{return new JSONObject(readBounded(in,600000));}finally{in.close();}
    }
    private synchronized void save(Request r,Answer a) throws Exception {
        JSONObject root;try{root=readCache();}catch(Exception e){root=new JSONObject();}
        root.put(r.key(),a.json());
        while(root.length()>60) {
            String oldest=null;long time=Long.MAX_VALUE;Iterator<String> it=root.keys();
            while(it.hasNext()){String k=it.next();long t=root.getJSONObject(k).optLong("time",0);if(oldest==null||t<time){oldest=k;time=t;}}
            root.remove(oldest);
        }
        cache.getParentFile().mkdirs();File tmp=new File(cache.getPath()+".tmp");
        FileOutputStream out=new FileOutputStream(tmp);try{out.write(root.toString().getBytes("UTF-8"));out.getFD().sync();}finally{out.close();}
        if(!tmp.renameTo(cache))throw new IOException("Cache write failed");
    }
    public Answer fetch(Request r,boolean online,long now) throws Exception {
        if(!online){Answer a=cached(r,now);if(a!=null)return a;throw new Unavailable("Çevrimdışısınız. Bu sorgu için kayıtlı veri yok. Yerel komutları kullanabilirsiniz.");}
        try {
            Answer a;
            if(r.kind.equals("weather"))a=weather(r.query,now);
            else if(r.kind.equals("currency"))a=currency(r.query,now);
            else if(r.kind.equals("wiki"))a=wiki(r.query,now);
            else throw new Unavailable("Bu veri türü desteklenmiyor.");
            try{save(r,a);}catch(Exception ignored){}return a;
        } catch(Exception e) {
            if(Thread.currentThread().isInterrupted())throw e;
            Answer a=cached(r,now);if(a!=null){a.cached=true;return a;}
            if(e instanceof Unavailable)throw e;
            throw new Unavailable("Veri servisine ulaşılamadı. Bağlantı zayıf veya servis geçici olarak kapalı olabilir. Yerel komutlar çalışmaya devam eder.");
        }
    }
    private static String enc(String q)throws Exception{return URLEncoder.encode(q,"UTF-8");}
    private Answer weather(String city,long now)throws Exception {
        JSONObject geo=new JSONObject(transport.get("https://geocoding-api.open-meteo.com/v1/search?name="+enc(city)+"&count=5&language=tr&format=json"));
        JSONArray results=geo.optJSONArray("results");if(results==null||results.length()==0)throw new Unavailable("Bu şehir bulunamadı. Örnek: Kahramanmaraş hava durumu.");
        JSONObject place=results.getJSONObject(0);for(int i=0;i<results.length();i++){JSONObject p=results.getJSONObject(i);if("TR".equals(p.optString("country_code"))){place=p;break;}}
        String url="https://api.open-meteo.com/v1/forecast?latitude="+place.getDouble("latitude")+"&longitude="+place.getDouble("longitude")+"&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m&timezone=auto";
        JSONObject data=new JSONObject(transport.get(url)),cur=data.getJSONObject("current");
        double temp=cur.getDouble("temperature_2m");if(Double.isNaN(temp)||Double.isInfinite(temp))throw new IOException("Invalid temperature");
        String title=place.getString("name")+" · "+place.optString("country","");
        String body=format(temp)+" °C • "+weatherLabel(cur.getInt("weather_code"))+"\nHissedilen: "+format(cur.getDouble("apparent_temperature"))+" °C\nNem: %"+cur.getInt("relative_humidity_2m")+" • Rüzgâr: "+format(cur.getDouble("wind_speed_10m"))+" km/sa\nModel zamanı: "+cur.getString("time").replace('T',' ')+" ("+data.optString("timezone","yerel")+")";
        return new Answer(title,body,"Open-Meteo · model tabanlı hava verisi",url,now);
    }
    public static String weatherLabel(int c) {
        if(c==0)return "Açık";if(c<=3)return "Parçalı / çok bulutlu";if(c==45||c==48)return "Sisli";
        if(c>=51&&c<=57)return "Çisenti";if(c>=61&&c<=67)return "Yağmurlu";
        if(c>=71&&c<=77)return "Karlı";if(c>=80&&c<=82)return "Sağanak yağış";if(c==85||c==86)return "Kar sağanağı";if(c>=95)return "Gök gürültülü";return "Kod "+c;
    }
    private Answer currency(String unit,long now)throws Exception {
        String url="https://api.frankfurter.dev/v1/latest?base="+unit+"&symbols=TRY";
        JSONObject j=new JSONObject(transport.get(url));double rate=j.getJSONObject("rates").getDouble("TRY");if(rate<=0)throw new IOException("Invalid rate");
        return new Answer(unit+" / TRY", "1 "+unit+" = "+new DecimalFormat("0.0000").format(rate)+" TL\nReferans tarihi: "+j.getString("date")+"\nGünlük referans kurudur; anlık banka alış/satış fiyatı değildir.","Frankfurter · ECB referans verisi",url,now);
    }
    private Answer wiki(String query,long now)throws Exception {
        if(query.length()==0)throw new Unavailable("Hangi konuda bilgi istediğinizi yazın.");
        String url="https://tr.wikipedia.org/w/api.php?action=query&format=json&formatversion=2&generator=search&gsrnamespace=0&gsrlimit=1&gsrsearch="+enc(query)+"&prop=extracts%7Cinfo&exintro=1&explaintext=1&exchars=1800&inprop=url";
        JSONObject j=new JSONObject(transport.get(url));JSONObject result=j.optJSONObject("query");JSONArray pages=result==null?null:result.optJSONArray("pages");
        if(pages==null||pages.length()==0)throw new Unavailable("Wikipedia'da bu sorguyla eşleşen bilgi bulunamadı.");
        JSONObject p=pages.getJSONObject(0);String body=p.optString("extract").trim();if(body.length()==0)throw new Unavailable("Bu konu için okunabilir bir özet bulunamadı.");
        return new Answer(p.getString("title"),body,"Wikipedia · en ilgili arama eşleşmesi",p.optString("fullurl","https://tr.wikipedia.org/wiki/"+enc(p.getString("title"))),now);
    }
    public static String format(double d){return new DecimalFormat("0.##########").format(d);}
    public static String readBounded(InputStream in,int max)throws Exception {
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n,total=0;
        while((n=in.read(buf))!=-1){if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();total+=n;if(total>max)throw new IOException("Response too large");out.write(buf,0,n);}
        return out.toString("UTF-8");
    }
    public static class HttpsTransport implements Transport {
        private volatile HttpURLConnection active;
        public void cancel(){HttpURLConnection c=active;if(c!=null)c.disconnect();}
        public String get(String address)throws Exception {
            URL url=new URL(address);String host=url.getHost();
            if(!"https".equals(url.getProtocol())||!Arrays.asList("geocoding-api.open-meteo.com","api.open-meteo.com","api.frankfurter.dev","tr.wikipedia.org").contains(host))throw new IOException("Untrusted endpoint");
            HttpURLConnection c=(HttpURLConnection)url.openConnection();active=c;
            c.setConnectTimeout(4500);c.setReadTimeout(5500);c.setInstanceFollowRedirects(false);c.setRequestProperty("Accept","application/json");c.setRequestProperty("User-Agent","JarvisAndroid/1.5.8 (personal assistant)");
            try {if(c.getResponseCode()!=200)throw new IOException("HTTP "+c.getResponseCode());InputStream in=c.getInputStream();try{return readBounded(in,262144);}finally{in.close();}}
            finally{c.disconnect();if(active==c)active=null;}
        }
    }
    public static double calculate(String s) throws Exception {return new MathParser(s).parse();}
    private static class MathParser {
        final String s;int p,depth;
        MathParser(String raw){s=raw.replace(',','.').replace('×','*').replace('÷','/').replaceAll("\\s","");}
        double parse()throws Exception{if(s.length()==0||s.length()>160)throw new Exception();double v=expr();if(p!=s.length()||Double.isInfinite(v)||Double.isNaN(v))throw new Exception();return v;}
        boolean eat(char c){if(p<s.length()&&s.charAt(p)==c){p++;return true;}return false;}
        double expr()throws Exception{double v=term();while(p<s.length()){if(eat('+'))v+=term();else if(eat('-'))v-=term();else break;}return v;}
        double term()throws Exception{double v=factor();while(p<s.length()){if(eat('*'))v*=factor();else if(eat('/')){double n=factor();if(n==0)throw new Exception();v/=n;}else break;}return v;}
        double factor()throws Exception{if(++depth>32)throw new Exception();double v;if(eat('+'))v=factor();else if(eat('-'))v=-factor();else if(eat('(')){v=expr();if(!eat(')'))throw new Exception();}else{int a=p;while(p<s.length()&&(Character.isDigit(s.charAt(p))||s.charAt(p)=='.'))p++;if(a==p)throw new Exception();v=Double.parseDouble(s.substring(a,p));}depth--;return v;}
    }
}
