package com.hakan.jarvis;
import android.Manifest;import android.app.*;import android.content.*;import android.content.pm.*;import android.hardware.camera2.*;import android.os.*;import android.provider.AlarmClock;import java.util.*;
/** Executes only after the host's real audio completion callback. */
public final class PhoneActions {
 public interface Host {void say(String text,String key,Runnable after);void show(String title,String detail);}
 private final Activity activity;private final Host host;private final Handler handler=new Handler(Looper.getMainLooper());
 private CameraManager camera;private String torchId;private boolean waitingTorch;private boolean requestedTorch;private int epoch;private PhoneCommand permissionPending;
 private final CameraManager.TorchCallback callback=new CameraManager.TorchCallback(){
  public void onTorchModeChanged(String id,boolean enabled){if(waitingTorch&&id.equals(torchId)&&enabled==requestedTorch){waitingTorch=false;handler.removeCallbacks(torchTimeout);host.show(enabled?"Fener açık":"Fener kapalı","Telefonun fener durumu doğrulandı.");}}
  public void onTorchModeUnavailable(String id){if(waitingTorch&&id.equals(torchId)){waitingTorch=false;handler.removeCallbacks(torchTimeout);error("Fener kullanılamıyor","Kamera başka bir uygulama tarafından kullanılıyor olabilir.","torch_error");}}
 };
 private final Runnable torchTimeout=new Runnable(){public void run(){if(waitingTorch){waitingTorch=false;error("Fener durumu doğrulanamadı","Telefonun fenerini kontrol edin. İşlemin tamamlandığı doğrulanamadı.","torch_error");}}};
 public PhoneActions(Activity a,Host h){activity=a;host=h;camera=(CameraManager)a.getSystemService(Context.CAMERA_SERVICE);if(camera!=null)try{camera.registerTorchCallback(callback,handler);}catch(RuntimeException ignored){}}
 public void cancel(){epoch++;permissionPending=null;waitingTorch=false;handler.removeCallbacks(torchTimeout);}
 public void pause(){if(permissionPending==null)cancel();}
 public void destroy(){cancel();if(camera!=null)try{camera.unregisterTorchCallback(callback);}catch(RuntimeException ignored){}handler.removeCallbacksAndMessages(null);}
 private void error(String title,String message,String key){host.show(title,message);host.say("",key,null);}
 public void handle(final PhoneCommand command){
  cancel();if(command.error!=null){error("Komutu netleştirin",command.error,command.kind.equals("alarm")?"alarm_invalid":"phone_clarify");return;}
  if(command.kind.equals("app")){openApp(command.target);return;}
  if(command.kind.equals("alarm")){alarm(command);return;}
  if(command.kind.equals("torch")){torch(command);}
 }
 private void openApp(String target){
  PackageManager pm=activity.getPackageManager();List<ResolveInfo> all=pm.queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),0);
  final LinkedHashMap<String,ResolveInfo> matches=new LinkedHashMap<String,ResolveInfo>();
  String alias=target.replace(" ","").replaceFirst("'(yi|yu|i|u)$","");String known=null;
  if(alias.matches("youtube?|yutub.?"))known="com.google.android.youtube";
  if(alias.matches("spotify?|spotif."))known="com.spotify.music";
  if(alias.matches("whatsapp?|vatsap"))known="com.whatsapp";
  if(alias.matches("instagram?(i)?$"))known="com.instagram.android";
  for(ResolveInfo ri:all){if(ri.activityInfo==null||activity.getPackageName().equals(ri.activityInfo.packageName))continue;
   if(PhoneCommand.matchesLabel(target,ri.loadLabel(pm).toString())||(known!=null&&known.equals(ri.activityInfo.packageName)))matches.put(ri.activityInfo.packageName,ri);
  }
  if(matches.isEmpty()){error("Uygulama bulunamadı",target+" için açılabilir yüklü uygulama bulunamadı. Telefonda görünen tam uygulama adını söyleyin.","app_missing");return;}
  if(matches.size()>1){
   final ResolveInfo[] options=matches.values().toArray(new ResolveInfo[0]);String[] names=new String[options.length];for(int i=0;i<options.length;i++)names[i]=options[i].loadLabel(pm)+" · "+options[i].activityInfo.packageName;
   host.show("Uygulama seçin","Aynı ada uyan birden fazla uygulama bulundu.");host.say("","app_choose",null);final int expected=epoch;
   new AlertDialog.Builder(activity).setTitle("Hangi uygulama?").setItems(names,new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int index){if(epoch==expected)launch(options[index]);}}).setNegativeButton("Vazgeç",null).show();return;
  }
  launch(matches.values().iterator().next());
 }
 private void launch(ResolveInfo ri){
  final Intent intent=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(new ComponentName(ri.activityInfo.packageName,ri.activityInfo.name)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
  final String label=ri.loadLabel(activity.getPackageManager()).toString();final int expected=epoch;
  host.show("Uygulama açılacak",label+" · Sesli yanıt tamamlanınca açılacak.");
  host.say(label+" uygulamasını açıyorum efendim.","app_open",new Runnable(){public void run(){if(epoch!=expected||activity.isFinishing())return;try{activity.startActivity(intent);}catch(RuntimeException e){error("Uygulama açılamadı","Uygulama kaldırılmış, devre dışı bırakılmış veya erişim engellenmiş olabilir.","app_error");}}});
 }
 public static Intent alarmIntent(PhoneCommand c){return new Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR,c.hour).putExtra(AlarmClock.EXTRA_MINUTES,c.minute).putExtra(AlarmClock.EXTRA_MESSAGE,"JARVIS").putExtra(AlarmClock.EXTRA_SKIP_UI,false);}
 private void alarm(final PhoneCommand c){
  if(c.plan==null||c.plan.error!=null){error("Alarm çözümlenemedi","Gün ve saati yeniden belirtin.","alarm_invalid");return;}
  if(!AlarmStore.permitted(activity)){error("Alarm bu Android hedefinde desteklenmiyor","JARVIS bu sürümde alarm izni ekranı açmaz.","alarm_error");return;}
  if(!AlarmStore.notifications(activity)){error("Alarm bildirimi kapalı","Bildirim iznini açtıktan sonra alarm komutunu yeniden söyleyin.","alarm_permission");new AlertDialog.Builder(activity).setTitle("Bildirim izni").setMessage("Alarm ekranını ve durdurma düğmesini göstermek için bildirimleri açın.").setPositiveButton("AYARLAR",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){activity.startActivity(new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,android.net.Uri.parse("package:"+activity.getPackageName())));}}).setNegativeButton("Vazgeç",null).show();return;}
  if(((android.media.AudioManager)activity.getSystemService(Context.AUDIO_SERVICE)).getStreamVolume(android.media.AudioManager.STREAM_ALARM)==0){error("Alarm sesi kapalı","Telefonun ALARM sesini yükseltin; ardından komutu tekrarlayın. Alarm henüz kurulmadı.","alarm_volume");return;}
  final int expected=epoch;host.show("Alarm kurulacak",c.plan.label()+"\nSesli yanıtın ardından kaydedilecek.");
  host.say("Alarmı "+c.plan.label()+" için kuruyorum efendim.","alarm_schedule",new Runnable(){public void run(){if(epoch!=expected||activity.isFinishing())return;try{int id=AlarmStore.schedule(activity,c.plan.when,c.plan.label());host.show("Alarm kuruldu",c.plan.label()+"\nTek seferlik · Kayıt #"+id+"\nALARMLARIM bölümünden kontrol edebilir veya silebilirsiniz.");}catch(Exception e){error("Alarm kurulamadı",e.getMessage()==null?"İzin ve saat ayarlarını kontrol edin.":e.getMessage(),"alarm_error");}}});
 }
 private void torch(final PhoneCommand c){
  if(camera==null){error("Fener desteklenmiyor","Bu cihazda kullanılabilir kamera/flaş yok.","torch_missing");return;}
  try{
   torchId=null;for(String id:camera.getCameraIdList()){CameraCharacteristics cc=camera.getCameraCharacteristics(id);if(Boolean.TRUE.equals(cc.get(CameraCharacteristics.FLASH_INFO_AVAILABLE))){torchId=id;Integer face=cc.get(CameraCharacteristics.LENS_FACING);if(face!=null&&face==CameraCharacteristics.LENS_FACING_BACK)break;}}
   if(torchId==null){error("Fener desteklenmiyor","Bu cihazda flaş donanımı bulunamadı.","torch_missing");return;}
  }catch(Exception e){error("Kameraya erişilemiyor","Kamera servisine erişilemedi. Tekrar deneyin.","torch_error");return;}
  if(activity.checkSelfPermission(Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED){
   host.show("Kamera izni gerekiyor","Android, fener kontrolü için kamera izni ister.");final int expected=epoch;
   host.say("","torch_permission",new Runnable(){public void run(){if(expected!=epoch)return;permissionPending=c;activity.requestPermissions(new String[]{Manifest.permission.CAMERA},811);}});return;
  }
  final int expected=epoch;host.show(c.enabled?"Fener açılacak":"Fener kapatılacak","Sesli yanıt tamamlanınca uygulanacak.");
  host.say("",c.enabled?"torch_on":"torch_off",new Runnable(){public void run(){if(epoch!=expected||activity.isFinishing())return;try{waitingTorch=true;requestedTorch=c.enabled;camera.setTorchMode(torchId,c.enabled);handler.postDelayed(torchTimeout,4000);}catch(Exception e){waitingTorch=false;error("Fener değiştirilemedi","Kamera meşgul, izin kapalı veya flaş kullanılamıyor olabilir.","torch_error");}}});
 }
 public boolean permissions(int code,int[] grants){if(code!=811)return false;PhoneCommand c=permissionPending;permissionPending=null;if(c==null)return true;if(grants.length>0&&grants[0]==PackageManager.PERMISSION_GRANTED)handle(c);else error("Kamera izni kapalı","Fener için Ayarlar > Uygulamalar > JARVIS > İzinler bölümünden kamera iznini açabilirsiniz.","torch_denied");return true;}
}
