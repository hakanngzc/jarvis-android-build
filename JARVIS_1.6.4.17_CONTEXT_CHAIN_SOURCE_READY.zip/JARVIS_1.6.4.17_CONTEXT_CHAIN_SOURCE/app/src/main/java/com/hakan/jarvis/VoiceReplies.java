package com.hakan.jarvis;

/** Response intent selection stays separate from playback and cannot claim unperformed actions. */
public final class VoiceReplies {
 public static String localKey(String title,String text){
  if(title.equals("Saat"))return "time";if(title.equals("Bugün"))return "date";
  if(title.equals("Hesaplama"))return "calculation";if(title.equals("Hesaplanamadı"))return "calculation_error";
  if(title.equals("Not kaydedildi"))return "note_saved";if(title.equals("Not alanı dolu"))return "note_full";
  if(title.equals("Notlarım"))return text.startsWith("Henüz")?"notes_empty":"notes";
  if(title.equals("Bağlantı"))return text.startsWith("İnternet")?"online":"offline";
  if(title.equals("Önbellek temizlendi"))return "cache_cleared";
  if(title.equals("Güncel hava verisi"))return "unsupported_weather";
  if(title.equals("Hibrit yardım"))return "help";
  if(title.equals("Komut çok uzun"))return "too_long";
  if(title.equals("İptal edildi")||title.equals("Dinleme durduruldu"))return "cancel";
  if(title.equals("Dinleme sona erdi")||title.equals("Ses anlaşılamadı"))return "recognition_error";
  if(title.equals("Çevrimdışı ses modeli yok"))return "offline_model";
  if(title.equals("Mikrofon izni kapalı"))return "mic_denied";
  if(title.startsWith("Ses tanıma"))return "recognition_unavailable";
  return "error";
 }
 public static String localText(String title,String text){
  if(title.equals("Saat"))return "Saat "+text.replace(':',' ')+", efendim.";
  if(title.equals("Bugün"))return "Bugün "+text+", efendim.";
  if(title.equals("Hesaplama")){int i=text.indexOf(" = ");return "Sonuç "+(i>=0?text.substring(i+3):text)+", efendim.";}
  if(title.equals("Notlarım")&&!text.startsWith("Henüz"))return "Kaydettiğiniz notlar, efendim. "+shorten(text,480);
  // Exact pre-rendered same-voice responses are immediate for fixed events.
  return "";
 }
 public static String legacyKey(String intent,String target,boolean action){
  String s=HybridEngine.normalize(intent+" "+target);
  if(s.contains("dusuk")||s.contains("belirsiz")||s.contains("hedef cozulmedi"))return "clarify";
  if(s.contains("islem yok"))return "unknown";
  if(action)return s.contains("kisi")?"open_editor":"open_action";
  if(s.contains("muzik")||s.contains("uygulama")||s.contains("fener")||s.contains("kisi ara")||s.contains("web arama"))return "not_executed";
  return "ack";
 }
 public static String answerText(HybridEngine.Answer a){
  String prefix=a.cached?(a.stale?"Bu bilgi eski bir kayıttan, efendim. Güncelliğini yitirmiş olabilir. ":"Kayıtlı bilgiyi okuyorum efendim. Şu anda internetten doğrulanmadı. "):"Efendim. ";
  String body=a.text;int at=body.indexOf("\nModel zamanı:");if(at>=0)body=body.substring(0,at);
  return prefix+a.title+". "+shorten(body,470).replace("°C"," derece").replace("km/sa"," kilometre bölü saat").replace("USD","dolar").replace("EUR","avro").replace("GBP","sterlin").replace("TRY","Türk lirası").replace("TL","Türk lirası").replace("•",".");
 }
 public static String answerKey(HybridEngine.Request r,HybridEngine.Answer a){if(a.cached)return a.stale?"stale":"cached";return r.kind.equals("weather")?"weather":r.kind.equals("currency")?"currency":"knowledge";}
 public static String shorten(String s,int length){if(s.length()<=length)return s;int stop=s.lastIndexOf('.',length);if(stop<length/2)stop=s.lastIndexOf(' ',length);if(stop<0)stop=length;return s.substring(0,stop)+". Devamını ekranda görebilirsiniz.";}
}
