package com.hakan.jarvis;
/** Exact, bounded linguistic rewrites; never edits the body of a note. */
public final class CommandLanguage {
 public static boolean isWake(String raw){
  String s=PhoneCommand.norm(raw).trim();
  return s.matches("^(?:hey )?(?:[jc]arvi[sz]|[cj]ervis)[,:]?$");
 }
 public static String clean(String raw){
  String s=PhoneCommand.norm(raw).replaceFirst("^(hey )?([jc]arvi[sz]|[cj]ervis)[,:]? +","").replaceAll("[?!.,]+$","").trim();
  s=s.replaceFirst("^lutfen +","").replaceFirst(" +lutfen$","");
  if(s.startsWith("not al ")||s.startsWith("not et ")||s.startsWith("not kaydet "))return s.replaceFirst("^not (?:et|kaydet) ","not al ");
  s=s.replaceFirst("^(?:bana|benim icin) +","");
  s=s.replaceAll("\\b(?:ayarlar|ayarlayabilir) misin(?:iz)?$","ayarla");
  s=s.replaceAll("\\b(ac|kapat|yak|sondur|baslat|kur|ayarla|ekle|uyandir)(?:[aeiu]r|[ae]bilir)?? misin(?:iz)?$","$1")
   .replaceAll("\\b(ac|kapat|yak|sondur|baslat|kur|ayarla|ekle|uyandir)(?:[aeiu]r|[ae]bilir|sana|iver)?$(?:)??","$1")
   .replaceFirst("^bi?r? +|^hadi","").trim();
  s=s.replaceFirst("^(?:telefonun |telefonumun )?(?:isigi|flasi|feneri|el feneri)(?:ni)?? ","feneri ");
  s=s.replaceFirst("^(?:uygulama olarak )","");
  if(s.startsWith("ac ")&&!s.contains(" ve "))s=s.substring(3)+" ac";
  if(s.equals("notlarimi oku")||s.equals("notlarimi listele"))s="notlarim";
  if(s.equals("bugunun tarihini soyle"))s="tarih";
  if(s.equals("saati soyle")||s.equals("saat kacti"))s="saat kac";
  return s;
 }
 public static String canonical(String raw){
  String s=raw.trim().replaceFirst("(?iu)^(hey )?([jc]arvi[sz]|[cj]ervis)[,:]? +","").replaceFirst("(?iu)^lütfen +","");
  if(s.matches("(?isu)^not (?:al|et|kaydet) .+"))return s.replaceFirst("(?iu)^not (?:et|kaydet) ","not al ");
  String n=clean(s);if(n.equals("notlarim")||n.equals("tarih")||n.equals("saat kac"))return n;return s;
 }
 public static String identity(String raw){PhoneCommand c=PhoneCommand.parse(raw);if(c==null)return clean(raw);return c.kind+":"+c.target+":"+c.enabled+":"+c.hour+":"+c.minute+":"+(c.plan==null?"":c.plan.context+":"+c.plan.when/60000)+":"+c.error;}
 public static boolean conflict(java.util.List<String> texts){
  String first=null;for(String text:texts){PhoneCommand c=PhoneCommand.parse(text);if(c!=null&&c.error==null){String id=identity(text);if(first==null)first=id;else if(!first.equals(id))return true;}}return false;
 }
}
