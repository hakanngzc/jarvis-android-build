package com.hakan.jarvis;
import java.util.*;
import java.util.regex.*;

/** Safe first-stage parser for sequential Turkish commands. */
public final class CommandChain {
    public static final class Result {
        public final List<String> commands;
        public final String error;
        Result(List<String> c,String e){commands=c;error=e;}
        public boolean chained(){return commands.size()>1;}
    }
    private static final Pattern SEP=Pattern.compile("\\s+(?:ve\\s+)?(?:sonra|ardindan)\\s+");
    private static final Pattern DURATION=Pattern.compile(".*\\b(?:yarim|bir|iki|uc|dort|bes|alti|yedi|sekiz|dokuz|on|\\d+)\\s+(?:dakika|saat)\\s*$");
    private static final Pattern ALARM_AFTER=Pattern.compile("^(?:bir\\s+)?(?:alarm|uyandir|alarm\\s+kur).*$");
    private CommandChain(){}

    public static Result parse(String raw){
        String original=raw==null?"":raw.trim();
        if(original.length()==0)return new Result(Collections.<String>emptyList(),"Komut boş.");
        String normalized=PhoneCommand.norm(original).replace("ardından","ardindan");
        if(normalized.matches("^(?:ve )?(?:sonra|ardindan)\\b.*"))return new Result(Collections.<String>emptyList(),"İlk komut eksik.");
        Matcher m=SEP.matcher(normalized);
        ArrayList<Integer> cuts=new ArrayList<Integer>();
        while(m.find()){
            String left=normalized.substring(0,m.start()).trim();
            String right=normalized.substring(m.end()).trim();
            // “20 dakika sonra alarm kur” bir zincir değil, tek zaman ifadesidir.
            if(DURATION.matcher(left).matches() && ALARM_AFTER.matcher(right).matches())continue;
            cuts.add(m.start());cuts.add(m.end());
            break; // v1: en fazla iki işlem. Daha fazlası bilinçli olarak reddedilir.
        }
        if(cuts.isEmpty())return new Result(Collections.singletonList(original),null);
        int a=cuts.get(0),b=cuts.get(1);
        String first=original.substring(0,Math.min(a,original.length())).trim();
        // Normalizasyon karakter uzunluklarını değiştirebildiği için asıl metinde ayırıcıyı ayrıca bul.
        Matcher om=Pattern.compile("\\s+(?:ve\\s+)?(?:sonra|ardından|ardindan)\\s+",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(original);
        if(!om.find())return new Result(Collections.singletonList(original),null);
        first=original.substring(0,om.start()).trim();String second=original.substring(om.end()).trim();
        String nf=PhoneCommand.norm(first), ns=PhoneCommand.norm(second);
        if(DURATION.matcher(nf).matches() && ALARM_AFTER.matcher(ns).matches())return new Result(Collections.singletonList(original),null);
        if(first.length()==0||second.length()==0)return new Result(Collections.<String>emptyList(),"Zincirde iki komut da açıkça söylenmeli.");
        if(SEP.matcher(PhoneCommand.norm(second)).find())return new Result(Collections.<String>emptyList(),"Bu sürümde tek cümlede en fazla iki işlem desteklenir.");
        return new Result(Arrays.asList(first,second),null);
    }
}
