package com.hakan.jarvis;
import java.util.*;import java.util.regex.*;
/** Conservative Turkish parsing. Unsupported/ambiguous requests never become actions. */
public final class PhoneCommand {
 public final AlarmPlan plan;
 public final String kind,target,error;public final boolean enabled;public final int hour,minute;
 private PhoneCommand(String k,String t,boolean on,int h,int m,String e){kind=k;target=t;enabled=on;hour=h;minute=m;error=e;plan=null;}
 private PhoneCommand(AlarmPlan p){kind="alarm";target="";enabled=false;hour=p.hour;minute=p.minute;error=p.error;plan=p;}
 static PhoneCommand invalid(String k,String e){return new PhoneCommand(k,"",false,-1,-1,e);}
 public static String norm(String s){return s.toLowerCase(new Locale("tr","TR")).replace('ı','i').replace('ş','s').replace('ğ','g').replace('ü','u').replace('ö','o').replace('ç','c').replace('’','\'').trim().replaceAll("\\s+"," ");}
 public static PhoneCommand parse(String input){
  String s=CommandLanguage.clean(input);
  if(s.startsWith("not al ")||s.startsWith("hesapla ")||s.startsWith("bilgi ")||s.startsWith("wikipedia ")||s.endsWith(" nedir")||s.endsWith(" hakkinda bilgi"))return null;
  if(s.matches(".*\\b(?:fener|feneri|el feneri|flas|flasi)\\b.*")){
   if(s.matches("(?:el )?(?:fener|feneri|flas|flasi)(?:ni)? (ac|yak|kapat|sondur)"))return new PhoneCommand("torch","",s.endsWith("ac")||s.endsWith("yak"),-1,-1,null);
   return invalid("torch","Fener için ‘feneri aç’ veya ‘feneri kapat’ deyin.");
  }
  if(s.matches(".*\\balarm(?:i|imi|im)?\\b.*")||s.matches(".*\\buyandir\\b.*"))return alarm(s);
  Matcher app=Pattern.compile("^(?:uygulama )?(.+?) +(ac|baslat|gir(sene)?|calistir)()$").matcher(s);
  if(app.matches()){
   String t=app.group(1).replaceFirst(" +uyg.*$| +bi\\Z","").replaceFirst("'(?:yi|yu|y[ui]|i|u)$","").trim();
   // Other legacy actions (music/contact/web) retain their existing route.
   if(t.matches(".*\\b(sarki|muzik|fener|flas|wifi|bluetooth)\\b.*"))return null;
   return new PhoneCommand("app",t,false,-1,-1,null);
  }
  return null;
 }
 private static PhoneCommand alarm(String s){
  return new PhoneCommand(AlarmPlan.parse(s,System.currentTimeMillis(),TimeZone.getDefault()));
 }

 public String time(){return String.format(Locale.US,"%02d:%02d",hour,minute);}
 public static boolean matchesLabel(String query,String label){String l=norm(label),q=norm(query);if(l.equals(q))return true;return q.equals(l+"yi")||q.equals(l+"yu")||q.equals(l+"i")||q.equals(l+"u");}
}
